#!/bin/bash
# Build lcos-software-center_<version>_all.deb using plain dpkg-deb (no debhelper needed).
#
#   packaging/build-deb.sh [output-dir]      # default output dir: dist/
#   MAINTAINER="Name <mail@example.org>" packaging/build-deb.sh
#
# The version comes from lcos_software_center/__init__.py.
set -euo pipefail

cd "$(dirname "$0")/.."

PKG=lcos-software-center
VERSION=$(python3 -c '
import re
text = open("lcos_software_center/__init__.py").read()
print(re.search(r"__version__\s*=\s*\"([^\"]+)\"", text).group(1))
')
MAINTAINER=${MAINTAINER:-"BDM <noreply@lcos.invalid>"}
OUT=${1:-dist}

STAGE=$(mktemp -d)
trap 'rm -rf "$STAGE"' EXIT

# 1. Install into a staging tree using the project's own Makefile.
make install DESTDIR="$STAGE" PREFIX=/usr > /dev/null
find "$STAGE" -name __pycache__ -type d -prune -exec rm -rf {} +

# 2. Documentation required by Debian policy.
DOC="$STAGE/usr/share/doc/$PKG"
install -d "$DOC"
install -m644 README.md "$DOC/README.md"
install -m644 packaging/copyright "$DOC/copyright"
printf '%s (%s) unstable; urgency=medium\n\n  * Packaged release.\n\n -- %s  %s\n' \
    "$PKG" "$VERSION" "$MAINTAINER" "$(date -R)" | gzip -9n > "$DOC/changelog.gz"

# 3. Normalise permissions: everything 644/755, only the two programs executable.
find "$STAGE" -type d -exec chmod 755 {} +
find "$STAGE" -type f -exec chmod 644 {} +
chmod 755 "$STAGE/usr/bin/lcos-software-center" \
          "$STAGE/usr/libexec/lcos-software-center/lcos-sc-helper"

# 4. Control data.
install -d "$STAGE/DEBIAN"
SIZE=$(du -sk --exclude=DEBIAN "$STAGE" | cut -f1)
sed -e "s|@VERSION@|$VERSION|" -e "s|@SIZE@|$SIZE|" -e "s|@MAINTAINER@|$MAINTAINER|" \
    packaging/control.in > "$STAGE/DEBIAN/control"
(cd "$STAGE" && find usr -type f -print0 | sort -z | xargs -0 md5sum) > "$STAGE/DEBIAN/md5sums"
install -m755 packaging/prerm "$STAGE/DEBIAN/prerm"
chmod 644 "$STAGE/DEBIAN/control" "$STAGE/DEBIAN/md5sums"

# 5. Build.
mkdir -p "$OUT"
dpkg-deb --root-owner-group --build "$STAGE" "$OUT/${PKG}_${VERSION}_all.deb"
echo "Built $OUT/${PKG}_${VERSION}_all.deb"
