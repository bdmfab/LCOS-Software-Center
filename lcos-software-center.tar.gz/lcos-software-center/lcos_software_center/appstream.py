"""Minimal AppStream catalog reader (XML only, standard library only).

Reads the catalogs that Debian/Devuan packages and Flatpak remotes ship, so the
store can show proper names, summaries, categories and icons.
"""

import glob
import gzip
import os
import xml.etree.ElementTree as ET
import zlib
from dataclasses import dataclass, field
from typing import Dict, Iterator, List, Optional, Sequence, Tuple

XML_LANG = "{http://www.w3.org/XML/1998/namespace}lang"
APP_TYPES = {"desktop-application", "desktop"}

SYSTEM_XML_DIRS = [
    "/usr/share/swcatalog/xml",
    "/var/lib/swcatalog/xml",
    "/var/cache/swcatalog/xml",
    "/usr/share/app-info/xmls",
    "/var/lib/app-info/xmls",
]


@dataclass
class Component:
    id: str
    name: str = ""
    summary: str = ""
    description: str = ""
    pkgname: str = ""
    categories: List[str] = field(default_factory=list)
    stock_icon: str = ""
    cached_icons: List[Tuple[int, str]] = field(default_factory=list)  # (width, filename)
    extra_icons: List[str] = field(default_factory=list)               # absolute icon file paths
    homepage: str = ""
    origin: str = ""
    source_file: str = ""


class Catalog:
    def __init__(self) -> None:
        self.by_pkg: Dict[str, Component] = {}
        self.by_id: Dict[str, Component] = {}
        self.count = 0
        self.distro_count = 0   # components from the distribution's own catalog (not Flatpak, not local)
        self.files: List[str] = []

    def add(self, comp: Component, distro: bool = True) -> None:
        self.count += 1
        if distro:
            self.distro_count += 1
        if comp.pkgname:
            self.by_pkg.setdefault(comp.pkgname, comp)
        self.by_id.setdefault(comp.id, comp)


def current_langs(environ=None) -> List[str]:
    """Preferred locales, most specific first, e.g. ['de_DE', 'de']."""
    env = os.environ if environ is None else environ
    raw = ""
    for var in ("LANGUAGE", "LC_ALL", "LC_MESSAGES", "LANG"):
        raw = env.get(var, "")
        if raw:
            break
    langs: List[str] = []
    for part in raw.split(":"):
        part = part.split(".")[0].split("@")[0]
        if not part or part in ("C", "POSIX"):
            continue
        langs.append(part)
        short = part.split("_")[0]
        if short != part:
            langs.append(short)
    return langs


def _text(elem) -> str:
    return " ".join("".join(elem.itertext()).split())


def _pick(elem, tag: str, langs: Sequence[str]) -> str:
    by_lang: Dict[Optional[str], str] = {}
    for child in elem.findall(tag):
        by_lang.setdefault(child.get(XML_LANG), _text(child))
    for lang in langs:
        if by_lang.get(lang):
            return by_lang[lang]
    return by_lang.get(None, "")


def _description(elem, langs: Sequence[str]) -> str:
    """Description in the best available language.

    Catalogs carry translations two ways: one <description> per language (the compiled
    Flatpak/Flathub catalog does this, the untagged one is the default), or a single
    <description> whose <p>/<li> children are tagged. Both are handled, and a language
    that isn't asked for is never shown.
    """
    by_lang: Dict[Optional[str], List[str]] = {}
    for desc in elem.findall("description"):
        base = desc.get(XML_LANG)
        for child in desc:
            lang = child.get(XML_LANG) or base
            if child.tag == "p":
                text = _text(child)
                if text:
                    by_lang.setdefault(lang, []).append(text)
            elif child.tag in ("ul", "ol"):
                items: Dict[Optional[str], List[str]] = {}
                for li in child.findall("li"):
                    items.setdefault(li.get(XML_LANG) or lang, []).append("\u2022 " + _text(li))
                for item_lang, lines in items.items():
                    by_lang.setdefault(item_lang, []).append("\n".join(lines))
    for lang in list(langs) + [None]:
        if by_lang.get(lang):
            return "\n\n".join(by_lang[lang])
    return ""


def _build(elem, origin: str, path: str, langs: Sequence[str]) -> Optional[Component]:
    if elem.get("type", "") not in APP_TYPES:
        return None
    cid = (elem.findtext("id") or "").strip()
    if not cid:
        return None
    if cid.endswith(".desktop"):
        cid = cid[: -len(".desktop")]
    comp = Component(
        id=cid,
        name=_pick(elem, "name", langs),
        summary=_pick(elem, "summary", langs),
        description=_description(elem, langs),
        pkgname=(elem.findtext("pkgname") or "").strip(),
        categories=[(c.text or "").strip() for c in elem.findall("categories/category") if c.text],
        origin=elem.get("origin") or origin,
        source_file=path,
    )
    for icon in elem.findall("icon"):
        kind = icon.get("type", "")
        text = (icon.text or "").strip()
        if not text:
            continue
        if kind == "stock":
            comp.stock_icon = comp.stock_icon or text
        elif kind == "cached":
            try:
                width = int(icon.get("width") or 0)
            except ValueError:
                width = 0
            comp.cached_icons.append((width, text))
    for url in elem.findall("url"):
        if url.get("type") == "homepage" and url.text:
            comp.homepage = url.text.strip()
            break
    return comp


def iter_components(path: str, langs: Sequence[str] = ()) -> Iterator[Component]:
    opener = gzip.open if path.endswith(".gz") else open
    origin = ""
    try:
        with opener(path, "rb") as fh:
            for event, elem in ET.iterparse(fh, events=("start", "end")):
                if event == "start":
                    if elem.tag == "components":
                        origin = elem.get("origin", "")
                    continue
                if elem.tag != "component":
                    continue
                comp = _build(elem, origin, path, langs)
                elem.clear()
                if comp is not None:
                    yield comp
    except (OSError, EOFError, ET.ParseError, zlib.error):
        return


def flatpak_xml_files(home: Optional[str] = None) -> List[str]:
    home = home or os.path.expanduser("~")
    patterns = [
        "/var/lib/flatpak/appstream/*/*/active/appstream.xml.gz",
        os.path.join(home, ".local/share/flatpak/appstream/*/*/active/appstream.xml.gz"),
    ]
    files: List[str] = []
    for pattern in patterns:
        files.extend(sorted(glob.glob(pattern)))
    return files


def system_xml_files(dirs: Sequence[str] = SYSTEM_XML_DIRS) -> List[str]:
    files: List[str] = []
    for directory in dirs:
        files.extend(sorted(glob.glob(os.path.join(directory, "*.xml.gz"))))
        files.extend(sorted(glob.glob(os.path.join(directory, "*.xml"))))
    return files


def load_catalog(files: Optional[Sequence[str]] = None, langs: Optional[Sequence[str]] = None,
                 local_root: Optional[str] = None) -> Catalog:
    """Load distro + Flatpak catalogs, then metadata of locally installed apps.

    With no arguments (the production path) the standard locations are used and the
    local .desktop/MetaInfo files of installed packages are added as well. Passing
    `files` (tests) skips the local scan unless `local_root` is given too.
    """
    include_local = files is None or local_root is not None
    if files is None:
        files = system_xml_files() + flatpak_xml_files()
    if langs is None:
        langs = current_langs()
    catalog = Catalog()
    for path in files:
        distro = "/flatpak/appstream/" not in path.replace(os.sep, "/")
        before = catalog.count
        for comp in iter_components(path, langs):
            catalog.add(comp, distro=distro)
        if catalog.count > before:
            catalog.files.append(path)
    if include_local:
        from . import localmeta  # local import: localmeta depends on this module
        for comp in localmeta.load_local(local_root or "/", langs):
            catalog.add(comp, distro=False)
    return catalog


def icon_candidates(comp: Component) -> List[str]:
    """Absolute icon file paths (best size first, existence not checked) then the theme name."""
    out: List[str] = []
    base = os.path.dirname(comp.source_file)
    flatpak_layout = os.path.basename(comp.source_file) == "appstream.xml.gz"
    for width, fname in sorted(comp.cached_icons, key=lambda wf: abs((wf[0] or 64) - 64)):
        size = "%dx%d" % (width or 64, width or 64)
        if flatpak_layout:
            out.append(os.path.join(base, "icons", size, fname))
        else:
            out.append(os.path.join(os.path.dirname(base), "icons", comp.origin, size, fname))
    if comp.stock_icon:
        out.append(comp.stock_icon)
    out.extend(comp.extra_icons)
    return out
