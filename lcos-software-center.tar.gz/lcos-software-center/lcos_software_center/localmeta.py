"""Metadata for *installed* applications, read from their .desktop and MetaInfo files.

Used when the distribution ships no AppStream catalog (as on Devuan today). It gives
installed apps their real names, summaries, icons and categories. Packages that are
not installed have no such files on disk, so they fall back to Debian package data.
"""

import glob
import os
from typing import Dict, List, Optional, Sequence

from .appstream import Component, current_langs, iter_components

APP_DIRS = ("/usr/share/applications/",)
META_DIRS = ("/usr/share/metainfo/", "/usr/share/appdata/")
META_SUFFIXES = (".metainfo.xml", ".appdata.xml")
PIXMAP_DIR = "/usr/share/pixmaps"
IMAGE_EXTS = (".png", ".svg", ".svgz", ".xpm")


def file_owners(root: str = "/") -> Dict[str, str]:
    """Map '/usr/share/applications/x.desktop' -> package name, from dpkg's file lists."""
    info_dir = os.path.join(root, "var/lib/dpkg/info")
    prefixes = APP_DIRS + META_DIRS
    owners: Dict[str, str] = {}
    for list_path in glob.glob(os.path.join(info_dir, "*.list")):
        pkg = os.path.basename(list_path)[: -len(".list")].split(":")[0]   # drop ':amd64'
        try:
            with open(list_path, "r", encoding="utf-8", errors="replace") as fh:
                for line in fh:
                    line = line.rstrip("\n")
                    if line.startswith(prefixes) and line.endswith((".desktop",) + META_SUFFIXES):
                        owners[line] = pkg
        except OSError:
            continue
    return owners


def _localized(entry: Dict[str, str], key: str, langs: Sequence[str]) -> str:
    for lang in langs:
        value = entry.get("%s[%s]" % (key, lang))
        if value:
            return value
    return entry.get(key, "")


def _icon_fields(icon: str):
    """Return (theme_name, [absolute_paths]) for a desktop-entry Icon= value."""
    if not icon:
        return "", []
    if os.path.isabs(icon):
        return "", [icon]
    if icon.lower().endswith(IMAGE_EXTS):
        return "", [os.path.join(PIXMAP_DIR, icon)]
    return icon, [os.path.join(PIXMAP_DIR, icon + ext) for ext in (".png", ".svg", ".xpm")]


def parse_desktop(path: str, langs: Sequence[str] = ()) -> Optional[Component]:
    entry: Dict[str, str] = {}
    in_entry = False
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as fh:
            for raw in fh:
                line = raw.strip()
                if not line or line.startswith("#"):
                    continue
                if line.startswith("["):
                    in_entry = line == "[Desktop Entry]"
                    if not in_entry and entry:
                        break          # past the main group (e.g. [Desktop Action ...])
                    continue
                if in_entry and "=" in line:
                    key, _, value = line.partition("=")
                    entry.setdefault(key.strip(), value.strip())
    except OSError:
        return None

    if entry.get("Type", "Application") != "Application":
        return None
    if entry.get("NoDisplay", "").lower() == "true" or entry.get("Hidden", "").lower() == "true":
        return None
    name = _localized(entry, "Name", langs)
    if not name:
        return None
    theme_name, files = _icon_fields(entry.get("Icon", ""))
    return Component(
        id=os.path.basename(path)[: -len(".desktop")],
        name=name,
        summary=_localized(entry, "Comment", langs) or _localized(entry, "GenericName", langs),
        categories=[c for c in entry.get("Categories", "").split(";") if c],
        stock_icon=theme_name,
        extra_icons=files,
        origin="local",
        source_file=path,
    )


def load_local(root: str = "/", langs: Optional[Sequence[str]] = None) -> List[Component]:
    """One Component per installed package that ships a visible application launcher."""
    if langs is None:
        langs = current_langs()
    by_pkg: Dict[str, Component] = {}
    metas = []
    for path, pkg in sorted(file_owners(root).items()):
        real = path if root == "/" else os.path.join(root, path.lstrip("/"))
        if path.endswith(".desktop"):
            comp = parse_desktop(real, langs)
            if comp is not None:
                comp.pkgname = pkg
                by_pkg.setdefault(pkg, comp)       # first launcher of a package represents it
        else:
            metas.append((real, pkg))
    for real, pkg in metas:                         # MetaInfo adds description/homepage
        for meta in iter_components(real, langs):
            base = by_pkg.get(pkg)
            if base is None:
                meta.pkgname = pkg
                by_pkg[pkg] = meta
            else:
                base.description = base.description or meta.description
                base.homepage = base.homepage or meta.homepage
                base.summary = base.summary or meta.summary
            break
    return list(by_pkg.values())
