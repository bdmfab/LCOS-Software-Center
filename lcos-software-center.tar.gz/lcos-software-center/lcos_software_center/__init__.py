"""LCOS Software Center - an APT + Flatpak software store for Devuan-based systems."""

__version__ = "0.4.1"
APP_ID = "org.lcos.SoftwareCenter"
APP_NAME = "Software Center"
