"""LCOS Software Center - an APT + Flatpak software store for Devuan-based systems."""

__version__ = "0.3.5"
APP_ID = "org.lcos.SoftwareCenter"
APP_NAME = "Software Center"
