"""GTK 3 user interface."""

import os
import threading
from typing import Callable, Dict, List, Optional

import gi

gi.require_version("Gtk", "3.0")
from gi.repository import Gio, GdkPixbuf, GLib, Gtk, Pango  # noqa: E402

from . import APP_NAME, __version__, appstream, flatpak_backend, launcher, paths, repocheck, runner, sandbox_check, sourcesfix  # noqa: E402
from .apt_backend import AptBackend, init_warnings, simulate  # noqa: E402
from .categories import CATEGORIES, VIEWS  # noqa: E402
from .models import APT, FLATPAK, Item, human_size  # noqa: E402

MAX_ROWS = 700
SEARCH_DELAY_MS = 250
FALLBACK_ICON = "package-x-generic"


class IconProvider:
    """Loads and caches item icons lazily (only for rows that are actually drawn)."""

    def __init__(self) -> None:
        self.theme = Gtk.IconTheme.get_default()
        self.cache: Dict[tuple, Optional[GdkPixbuf.Pixbuf]] = {}

    def get(self, item: Item, size: int) -> Optional[GdkPixbuf.Pixbuf]:
        key = (item.key, size)
        if key in self.cache:
            return self.cache[key]
        pixbuf = None
        for candidate in item.icons:
            try:
                if os.path.isabs(candidate):
                    if os.path.isfile(candidate):
                        pixbuf = GdkPixbuf.Pixbuf.new_from_file_at_size(candidate, size, size)
                elif self.theme.has_icon(candidate):
                    pixbuf = self.theme.load_icon(candidate, size, 0)
            except GLib.Error:
                pixbuf = None
            if pixbuf is not None:
                break
        if pixbuf is None:
            try:
                pixbuf = self.theme.load_icon(FALLBACK_ICON, size, 0)
            except GLib.Error:
                pixbuf = None
        self.cache[key] = pixbuf
        return pixbuf


class SoftwareCenterWindow(Gtk.ApplicationWindow):
    def __init__(self, app: Gtk.Application) -> None:
        super().__init__(application=app, title=APP_NAME)
        self.set_default_size(1000, 680)
        self.set_icon_name("system-software-install")

        self.apt = AptBackend()
        self.icons = IconProvider()
        self.items: Dict[str, Item] = {}
        self.all_items: List[Item] = []
        self.catalog = appstream.Catalog()
        self.flatpak_state = {"installed": False, "has_remote": False}
        self.sandbox = sandbox_check.SandboxStatus()    # replaced by the real check after loading
        self.category = "all"
        self.source = "all"
        self.query = ""
        self.show_all_packages = False
        self.loaded = False
        self.busy = False
        self.current: Optional[Item] = None
        self.launchers: Dict[str, Optional[str]] = {}   # item.key -> .desktop path (APT items only)
        self._search_timer: Optional[int] = None
        self._pulsing = False

        self._build_ui()
        self.show_all()
        self.update_all_button.hide()
        self.progress_revealer.set_reveal_child(False)
        self._start_loading()

    # ------------------------------------------------------------------ construction

    def _build_ui(self) -> None:
        header = Gtk.HeaderBar()
        header.set_show_close_button(True)
        header.set_title(APP_NAME)
        self.set_titlebar(header)

        self.source_combo = Gtk.ComboBoxText()
        self.source_combo.append("all", "All sources")
        self.source_combo.append(APT, "Devuan (APT)")
        self.source_combo.append(FLATPAK, "Flatpak")
        self.source_combo.set_active_id("all")
        self.source_combo.connect("changed", self._on_source_changed)
        header.pack_start(self.source_combo)

        self.search = Gtk.SearchEntry()
        self.search.set_placeholder_text("Search software")
        self.search.set_width_chars(36)
        self.search.connect("search-changed", self._on_search_changed)
        header.set_custom_title(self.search)

        self.refresh_button = Gtk.Button.new_from_icon_name("view-refresh-symbolic", Gtk.IconSize.BUTTON)
        self.refresh_button.set_tooltip_text("Refresh package lists")
        self.refresh_button.connect("clicked", self._on_refresh_clicked)
        header.pack_end(self.refresh_button)
        about_button = Gtk.Button.new_from_icon_name("help-about-symbolic", Gtk.IconSize.BUTTON)
        about_button.set_tooltip_text("About %s" % APP_NAME)
        about_button.connect("clicked", self._on_about_clicked)
        header.pack_end(about_button)

        root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        self.add(root)

        self.infobox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        root.pack_start(self.infobox, False, False, 0)

        body = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        root.pack_start(body, True, True, 0)
        body.pack_start(self._build_sidebar(), False, False, 0)
        body.pack_start(Gtk.Separator(orientation=Gtk.Orientation.VERTICAL), False, False, 0)

        self.stack = Gtk.Stack()
        self.stack.add_named(self._build_loading_page(), "loading")
        self.stack.add_named(self._build_list_page(), "list")
        self.stack.add_named(self._build_detail_page(), "detail")
        body.pack_start(self.stack, True, True, 0)

        root.pack_start(self._build_progress_area(), False, False, 0)

    def _build_sidebar(self) -> Gtk.Widget:
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        box.set_size_request(210, -1)
        scroller = Gtk.ScrolledWindow()
        scroller.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        self.sidebar = Gtk.ListBox()
        self.sidebar.set_selection_mode(Gtk.SelectionMode.SINGLE)
        self.sidebar.connect("row-selected", self._on_category_selected)
        scroller.add(self.sidebar)
        box.pack_start(scroller, True, True, 0)

        self.sidebar_labels: Dict[str, Gtk.Label] = {}
        first_row = None
        for key, label, icon in VIEWS:
            row = self._sidebar_row(key, label, icon)
            self.sidebar.add(row)
            first_row = first_row or row
        heading = Gtk.ListBoxRow()
        heading.set_selectable(False)
        heading.set_activatable(False)
        title = Gtk.Label(xalign=0)
        title.set_markup("<small><b>CATEGORIES</b></small>")
        title.set_margin_start(12)
        title.set_margin_top(12)
        title.set_margin_bottom(4)
        heading.add(title)
        self.sidebar.add(heading)
        for key, label, icon in CATEGORIES:
            self.sidebar.add(self._sidebar_row(key, label, icon))

        self.all_packages_check = Gtk.CheckButton.new_with_label("Include all packages")
        self.all_packages_check.set_tooltip_text(
            "Also list libraries, development files and other non-application packages")
        self.all_packages_check.set_margin_start(12)
        self.all_packages_check.set_margin_top(8)
        self.all_packages_check.set_margin_bottom(8)
        self.all_packages_check.connect("toggled", self._on_all_packages_toggled)
        box.pack_start(Gtk.Separator(), False, False, 0)
        box.pack_start(self.all_packages_check, False, False, 0)

        self.sidebar.select_row(first_row)
        return box

    def _sidebar_row(self, key: str, text: str, icon: str) -> Gtk.ListBoxRow:
        row = Gtk.ListBoxRow()
        row.category_key = key
        hbox = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        hbox.set_margin_start(12)
        hbox.set_margin_end(12)
        hbox.set_margin_top(7)
        hbox.set_margin_bottom(7)
        hbox.pack_start(Gtk.Image.new_from_icon_name(icon, Gtk.IconSize.MENU), False, False, 0)
        label = Gtk.Label(label=text, xalign=0)
        hbox.pack_start(label, True, True, 0)
        row.add(hbox)
        self.sidebar_labels[key] = label
        return row

    def _build_loading_page(self) -> Gtk.Widget:
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        box.set_valign(Gtk.Align.CENTER)
        box.set_halign(Gtk.Align.CENTER)
        spinner = Gtk.Spinner()
        spinner.set_size_request(48, 48)
        spinner.start()
        box.pack_start(spinner, False, False, 0)
        self.loading_label = Gtk.Label(label="Loading software catalog…")
        box.pack_start(self.loading_label, False, False, 0)
        return box

    def _build_list_page(self) -> Gtk.Widget:
        page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)

        bar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        bar.set_margin_start(12)
        bar.set_margin_end(12)
        bar.set_margin_top(8)
        bar.set_margin_bottom(8)
        self.list_title = Gtk.Label(xalign=0)
        bar.pack_start(self.list_title, True, True, 0)
        self.update_all_button = Gtk.Button.new_with_label("Update all")
        self.update_all_button.get_style_context().add_class("suggested-action")
        self.update_all_button.connect("clicked", self._on_update_all_clicked)
        bar.pack_end(self.update_all_button, False, False, 0)
        page.pack_start(bar, False, False, 0)

        self.store = Gtk.ListStore(str, str, str, str)   # key, markup, source, status
        tree = Gtk.TreeView(model=self.store)
        tree.set_headers_visible(False)
        tree.set_enable_search(False)
        tree.set_rules_hint(True)
        tree.connect("row-activated", self._on_row_activated)

        icon_cell = Gtk.CellRendererPixbuf()
        icon_cell.set_padding(10, 8)
        icon_col = Gtk.TreeViewColumn("", icon_cell)
        icon_col.set_cell_data_func(icon_cell, self._icon_data_func)
        tree.append_column(icon_col)

        text_cell = Gtk.CellRendererText()
        text_cell.set_property("ellipsize", Pango.EllipsizeMode.END)
        text_col = Gtk.TreeViewColumn("", text_cell, markup=1)
        text_col.set_expand(True)
        tree.append_column(text_col)

        source_cell = Gtk.CellRendererText()
        source_cell.set_property("xpad", 12)
        tree.append_column(Gtk.TreeViewColumn("", source_cell, markup=2))

        status_cell = Gtk.CellRendererText()
        status_cell.set_property("xpad", 12)
        status_cell.set_property("width-chars", 12)
        tree.append_column(Gtk.TreeViewColumn("", status_cell, markup=3))

        scroller = Gtk.ScrolledWindow()
        scroller.add(tree)
        page.pack_start(scroller, True, True, 0)

        self.status_label = Gtk.Label(xalign=0)
        self.status_label.set_margin_start(12)
        self.status_label.set_margin_top(4)
        self.status_label.set_margin_bottom(4)
        page.pack_start(self.status_label, False, False, 0)
        return page

    def _build_detail_page(self) -> Gtk.Widget:
        page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        for side in ("start", "end", "top", "bottom"):
            getattr(page, "set_margin_" + side)(18)

        back = Gtk.Button.new_with_label("‹ Back")
        back.set_halign(Gtk.Align.START)
        back.connect("clicked", lambda _b: self.stack.set_visible_child_name("list"))
        page.pack_start(back, False, False, 0)

        top = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=16)
        self.d_icon = Gtk.Image()
        top.pack_start(self.d_icon, False, False, 0)
        titles = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        self.d_name = Gtk.Label(xalign=0)
        self.d_summary = Gtk.Label(xalign=0)
        self.d_summary.set_line_wrap(True)
        titles.pack_start(self.d_name, False, False, 0)
        titles.pack_start(self.d_summary, False, False, 0)
        top.pack_start(titles, True, True, 0)

        buttons = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        buttons.set_valign(Gtk.Align.CENTER)
        self.d_button = Gtk.Button.new_with_label("Install")
        self.d_button.set_size_request(120, -1)
        self.d_button.connect("clicked", self._on_detail_action)
        self.d_update = Gtk.Button.new_with_label("Update")
        self.d_update.connect("clicked", self._on_detail_update)
        self.d_open = Gtk.Button.new_with_label("Open")
        self.d_open.connect("clicked", self._on_detail_open)
        buttons.pack_start(self.d_open, False, False, 0)
        buttons.pack_start(self.d_button, False, False, 0)
        buttons.pack_start(self.d_update, False, False, 0)
        top.pack_end(buttons, False, False, 0)
        page.pack_start(top, False, False, 0)

        grid = Gtk.Grid(column_spacing=16, row_spacing=4)
        self.d_meta: Dict[str, Gtk.Label] = {}
        for row, name in enumerate(("Source", "Version", "Download size", "Installed size")):
            key = Gtk.Label(label=name, xalign=0)
            key.get_style_context().add_class("dim-label")
            value = Gtk.Label(xalign=0)
            value.set_selectable(True)
            grid.attach(key, 0, row, 1, 1)
            grid.attach(value, 1, row, 1, 1)
            self.d_meta[name] = value
        site_key = Gtk.Label(label="Website", xalign=0)
        site_key.get_style_context().add_class("dim-label")
        self.d_site = Gtk.LinkButton.new_with_label("", "")
        self.d_site.set_halign(Gtk.Align.START)
        grid.attach(site_key, 0, 4, 1, 1)
        grid.attach(self.d_site, 1, 4, 1, 1)
        page.pack_start(grid, False, False, 0)

        scroller = Gtk.ScrolledWindow()
        scroller.set_shadow_type(Gtk.ShadowType.IN)
        self.d_desc = Gtk.Label(xalign=0, yalign=0)
        self.d_desc.set_line_wrap(True)
        self.d_desc.set_selectable(True)
        self.d_desc.set_margin_start(10)
        self.d_desc.set_margin_end(10)
        self.d_desc.set_margin_top(10)
        scroller.add(self.d_desc)
        page.pack_start(scroller, True, True, 0)
        return page

    def _build_progress_area(self) -> Gtk.Widget:
        self.progress_revealer = Gtk.Revealer()
        self.progress_revealer.set_transition_type(Gtk.RevealerTransitionType.SLIDE_UP)
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        for side in ("start", "end", "top", "bottom"):
            getattr(box, "set_margin_" + side)(10)
        self.progress_label = Gtk.Label(xalign=0)
        self.progress_bar = Gtk.ProgressBar()
        self.progress_bar.set_pulse_step(0.08)
        expander = Gtk.Expander.new("Details")
        self.log_buffer = Gtk.TextBuffer()
        self.log_view = Gtk.TextView(buffer=self.log_buffer)
        self.log_view.set_editable(False)
        self.log_view.set_monospace(True)
        log_scroller = Gtk.ScrolledWindow()
        log_scroller.set_min_content_height(160)
        log_scroller.add(self.log_view)
        expander.add(log_scroller)
        for widget in (self.progress_label, self.progress_bar, expander):
            box.pack_start(widget, False, False, 0)
        self.progress_revealer.add(box)
        return self.progress_revealer

    # ------------------------------------------------------------------ threading helper

    @staticmethod
    def _ui(fn: Callable, *args) -> None:
        """Run fn(*args) on the GTK main loop (safe to call from worker threads)."""
        def call():
            fn(*args)
            return False
        GLib.idle_add(call)

    # ------------------------------------------------------------------ loading

    def _start_loading(self) -> None:
        self.loaded = False
        self.stack.set_visible_child_name("loading")
        threading.Thread(target=self._load_thread, daemon=True).start()

    def _load_thread(self) -> None:
        errors: List[str] = []
        catalog = appstream.load_catalog()
        featured = paths.load_featured()
        apt_items: List[Item] = []
        if self.apt.available():
            try:
                apt_items = self.apt.load(catalog)
            except Exception as exc:  # noqa: BLE001 - surface any backend failure in the UI
                errors.append("Could not read the APT package cache: %s" % exc)
        else:
            errors.append("python3-apt is not installed, so APT packages can't be listed.")
        fp_items: List[Item] = []
        fp_state = {"installed": False, "has_remote": False}
        try:
            fp_items, fp_state = flatpak_backend.load(catalog)
        except Exception as exc:  # noqa: BLE001
            errors.append("Could not read Flatpak data: %s" % exc)
        for item in apt_items:
            item.featured = item.ident in featured["apt"]
        for item in fp_items:
            item.featured = item.ident in featured["flatpak"]
        issues = repocheck.check()
        fix = sourcesfix.plan() if any(i.kind == "suite-names" for i in issues) else None
        sandbox = sandbox_check.check() if fp_state["installed"] else sandbox_check.SandboxStatus()
        self._ui(self._loaded, catalog, apt_items + fp_items, fp_state, errors, issues, sandbox, fix)

    def _loaded(self, catalog, items, fp_state, errors, issues, sandbox, fix=None) -> None:
        self.catalog = catalog
        self.all_items = items
        self.items = {item.key: item for item in items}
        self.flatpak_state = fp_state
        self.sandbox = sandbox
        self.loaded = True
        self._clear_infobars()
        for issue in issues:
            kind = Gtk.MessageType.WARNING if issue.level == "warning" else Gtk.MessageType.INFO
            if issue.kind == "suite-names" and fix is not None:
                text = (issue.text + "\n" + sourcesfix.advice(fix)).strip()
                if fix.can_apply():
                    self._add_infobar(kind, text, "Fix it…", lambda f=fix: self._fix_sources(f))
                    continue
                self._add_infobar(kind, text)
                continue
            self._add_infobar(kind, issue.text)
        if not sandbox.ok:
            self._add_infobar(Gtk.MessageType.WARNING, sandbox.explanation())
        for error in errors:
            self._add_infobar(Gtk.MessageType.ERROR, error)
        if not fp_state["installed"]:
            self._add_infobar(
                Gtk.MessageType.INFO, "Flatpak is not installed, so Flatpak apps are unavailable.",
                "Install Flatpak", self._install_flatpak)
        elif not fp_state["has_remote"]:
            self._add_infobar(
                Gtk.MessageType.INFO, "Flathub isn't set up yet. Enable it to browse Flatpak apps.",
                "Enable Flathub", self._enable_flathub)
        self._update_updates_count()
        self.stack.set_visible_child_name("list")
        self._populate()

    def _reload_all(self) -> None:
        self._start_loading()

    # ------------------------------------------------------------------ info bars

    def _clear_infobars(self) -> None:
        for child in self.infobox.get_children():
            child.destroy()

    def _add_infobar(self, kind, text: str, button: Optional[str] = None,
                     callback: Optional[Callable[[], None]] = None) -> None:
        bar = Gtk.InfoBar()
        bar.set_message_type(kind)
        bar.set_show_close_button(True)
        label = Gtk.Label(label=text, xalign=0)
        label.set_line_wrap(True)
        label.set_selectable(True)
        bar.get_content_area().add(label)
        if button and callback:
            bar.add_button(button, Gtk.ResponseType.ACCEPT)

        def on_response(_bar, response):
            if response == Gtk.ResponseType.ACCEPT and callback:
                callback()
            _bar.destroy()
        bar.connect("response", on_response)
        self.infobox.pack_start(bar, False, False, 0)
        bar.show_all()

    # ------------------------------------------------------------------ list view

    def _icon_data_func(self, _col, cell, model, tree_iter, _data) -> None:
        item = self.items.get(model[tree_iter][0])
        if item is not None:
            cell.set_property("pixbuf", self.icons.get(item, 32))

    def _filtered(self) -> List[Item]:
        q = self.query.strip().lower()
        cat = self.category
        scored = []
        for item in self.all_items:
            if self.source != "all" and item.source != self.source:
                continue
            if cat == "installed":
                if not item.installed:
                    continue
            elif cat == "updates":
                if not (item.installed and item.upgradable):
                    continue
            elif cat == "featured":
                if not item.featured:
                    continue
            elif cat != "all" and cat not in item.categories:
                continue
            if not item.is_app and not self.show_all_packages and cat != "updates":
                continue
            score = 0
            if q:
                ident, name, summary = item.ident.lower(), item.name.lower(), item.summary.lower()
                if q in (ident, name):
                    score = 0
                elif ident.startswith(q) or name.startswith(q):
                    score = 1
                elif q in ident or q in name:
                    score = 2
                elif q in summary:
                    score = 3
                else:
                    continue
            scored.append((score, item.name.lower(), item.source, item))
        scored.sort(key=lambda t: t[:3])
        return [t[3] for t in scored]

    def _populate(self) -> None:
        matches = self._filtered()
        self.store.clear()
        for item in matches[:MAX_ROWS]:
            name = GLib.markup_escape_text(item.name)
            summary = GLib.markup_escape_text(item.summary)
            markup = "<b>%s</b>\n<small>%s</small>" % (name, summary)
            status = ""
            if item.installed:
                status = "<span foreground='#2e8b57'>Update available</span>" if item.upgradable else "Installed"
            self.store.append([item.key, markup, "<small>%s</small>" % item.source_label, status])
        text = "%d result%s" % (len(matches), "" if len(matches) == 1 else "s")
        if len(matches) > MAX_ROWS:
            text += " – showing the first %d, refine your search to narrow it down" % MAX_ROWS
        self.status_label.set_text(text)
        titles = {key: label for key, label, _ in VIEWS + CATEGORIES}
        self.list_title.set_markup("<big><b>%s</b></big>" % GLib.markup_escape_text(
            'Search results for "%s"' % self.query.strip() if self.query.strip()
            else titles.get(self.category, "")))
        self.update_all_button.set_visible(self.category == "updates" and bool(matches) and not self.busy)

    def _update_updates_count(self) -> None:
        count = sum(1 for i in self.all_items if i.installed and i.upgradable)
        self.sidebar_labels["updates"].set_text("Updates (%d)" % count if count else "Updates")

    # ------------------------------------------------------------------ list/search signals

    def _on_category_selected(self, _listbox, row) -> None:
        if row is None:
            return
        self.category = row.category_key
        if self.loaded:
            self.stack.set_visible_child_name("list")
            self._populate()

    def _on_source_changed(self, combo) -> None:
        self.source = combo.get_active_id() or "all"
        if self.loaded:
            self._populate()

    def _on_all_packages_toggled(self, button) -> None:
        self.show_all_packages = button.get_active()
        if self.loaded:
            self._populate()

    def _on_search_changed(self, entry) -> None:
        if self._search_timer is not None:
            GLib.source_remove(self._search_timer)
        self._search_timer = GLib.timeout_add(SEARCH_DELAY_MS, self._apply_search, entry.get_text())

    def _apply_search(self, text: str) -> bool:
        self._search_timer = None
        self.query = text
        if self.loaded:
            self.stack.set_visible_child_name("list")
            self._populate()
        return False

    def _on_row_activated(self, tree, path, _col) -> None:
        item = self.items.get(self.store[path][0])
        if item is not None:
            self._show_detail(item)

    # ------------------------------------------------------------------ detail view

    def _show_detail(self, item: Item) -> None:
        self.current = item
        self.d_icon.set_from_pixbuf(self.icons.get(item, 64))
        self._fill_detail(item)
        self.stack.set_visible_child_name("detail")
        if item.source == APT:
            threading.Thread(target=self._details_thread, args=(item,), daemon=True).start()

    def _details_thread(self, item: Item) -> None:
        self.apt.details(item)
        if item.installed and item.key not in self.launchers:
            self.launchers[item.key] = launcher.apt_launcher(item.ident)
        self._ui(self._fill_detail, item)

    def _fill_detail(self, item: Item) -> None:
        if item is not self.current:
            return
        self.d_name.set_markup("<span size='x-large' weight='bold'>%s</span>" % GLib.markup_escape_text(item.name))
        self.d_summary.set_text(item.summary)
        self.d_desc.set_text(item.description or item.summary or "No description available.")
        self.d_meta["Source"].set_text(
            item.source_label + (" – " + item.origin if item.source == FLATPAK and item.origin else ""))
        self.d_meta["Version"].set_text(item.version or "unknown")
        self.d_meta["Download size"].set_text(human_size(item.size))
        self.d_meta["Installed size"].set_text(human_size(item.installed_size))
        if item.homepage:
            self.d_site.set_uri(item.homepage)
            self.d_site.set_label(item.homepage)
            self.d_site.show()
        else:
            self.d_site.hide()
        self._update_detail_buttons()

    def _update_detail_buttons(self) -> None:
        item = self.current
        if item is None:
            return
        ctx = self.d_button.get_style_context()
        ctx.remove_class("suggested-action")
        ctx.remove_class("destructive-action")
        if item.installed:
            self.d_button.set_label("Remove")
            ctx.add_class("destructive-action")
        else:
            self.d_button.set_label("Install")
            ctx.add_class("suggested-action")
        self.d_button.set_sensitive(not self.busy)
        self.d_update.set_visible(item.installed and item.upgradable)
        self.d_update.set_sensitive(not self.busy)
        can_open = item.installed and (item.source == FLATPAK or bool(self.launchers.get(item.key)))
        self.d_open.set_visible(can_open)

    def _on_detail_open(self, _button) -> None:
        item = self.current
        if item is None:
            return
        error = None
        if item.source == FLATPAK:
            error = launcher.launch_flatpak(item)
        else:
            path = self.launchers.get(item.key)
            try:
                info = Gio.DesktopAppInfo.new_from_filename(path) if path else None
                if info is None:
                    error = "%s doesn't provide a launcher that can be started from here." % item.name
                else:
                    info.launch([], None)
            except GLib.Error as exc:
                error = "Could not start %s: %s" % (item.name, exc.message)
        if error:
            self._message("Can't open %s" % item.name, error, Gtk.MessageType.ERROR)

    def _on_detail_action(self, _button) -> None:
        if self.current is not None:
            self._request_action(self.current, "remove" if self.current.installed else "install")

    def _on_detail_update(self, _button) -> None:
        if self.current is not None:
            self._request_action(self.current, "update")

    # ------------------------------------------------------------------ actions

    def _request_action(self, item: Item, action: str) -> None:
        if self.busy:
            return
        if (item.source == FLATPAK and action == "install" and not self.sandbox.ok
                and not self._confirm("Flatpak apps won't start on this system yet",
                                      self.sandbox.explanation(), "Install anyway", destructive=False)):
            return
        if item.source == APT and action in ("install", "remove"):
            self._set_busy(True, "Checking what this change involves…")
            threading.Thread(target=self._simulate_thread, args=(item, action), daemon=True).start()
        else:
            self._begin_job(item, action)

    def _simulate_thread(self, item: Item, action: str) -> None:
        sim = simulate(action, [item.ident])
        self._ui(self._after_simulate, item, action, sim)

    def _after_simulate(self, item: Item, action: str, sim) -> None:
        self._set_busy(False)
        if sim.error:
            self._message("Can't %s %s" % (action, item.name), sim.error, Gtk.MessageType.ERROR)
            return
        warnings = init_warnings(sim)
        extras = [p for p in (sim.remove if action == "remove" else sim.install) if p != item.ident]
        if warnings or (action == "remove" and extras):
            lines = list(warnings)
            if extras:
                verb = "also be removed" if action == "remove" else "also be installed"
                shown = ", ".join(extras[:25]) + (" …" if len(extras) > 25 else "")
                lines.append("These packages would %s: %s" % (verb, shown))
            if not self._confirm("%s %s?" % (action.capitalize(), item.name), "\n\n".join(lines),
                                 action.capitalize(), dangerous=bool(warnings)):
                return
        self._begin_job(item, action)

    def _argv_for(self, item: Item, action: str) -> List[str]:
        if item.source == APT:
            return runner.helper_command("upgrade" if action == "update" else action, item.ident)
        return {"install": flatpak_backend.install_argv,
                "remove": flatpak_backend.remove_argv,
                "update": flatpak_backend.update_argv}[action](item)

    def _begin_job(self, item: Item, action: str) -> None:
        verbs = {"install": "Installing", "remove": "Removing", "update": "Updating"}
        try:
            argv = self._argv_for(item, action)
        except RuntimeError as exc:
            self._message("Cannot run the helper", str(exc), Gtk.MessageType.ERROR)
            return
        self._run_jobs("%s %s…" % (verbs[action], item.name), [argv])

    def _on_update_all_clicked(self, _button) -> None:
        if self.busy:
            return
        argvs: List[List[str]] = []
        try:
            if any(i.source == APT and i.installed and i.upgradable for i in self.all_items):
                argvs.append(runner.helper_command("upgrade-all"))
        except RuntimeError as exc:
            self._message("Cannot run the helper", str(exc), Gtk.MessageType.ERROR)
            return
        if any(i.source == FLATPAK and i.installed and i.upgradable for i in self.all_items):
            argvs.append(flatpak_backend.update_argv())
        if argvs:
            self._run_jobs("Installing updates…", argvs)

    def _on_refresh_clicked(self, _button) -> None:
        if self.busy:
            return
        argvs: List[List[str]] = []
        try:
            if self.apt.available():
                argvs.append(runner.helper_command("update"))
        except RuntimeError as exc:
            self._message("Cannot run the helper", str(exc), Gtk.MessageType.ERROR)
            return
        if flatpak_backend.available() and self.flatpak_state.get("has_remote"):
            argvs.append(flatpak_backend.update_appstream_argv())
        if argvs:
            self._run_jobs("Refreshing package lists…", argvs, after=self._reload_all)
        else:
            self._reload_all()

    def _on_about_clicked(self, _button) -> None:
        dialog = Gtk.AboutDialog(transient_for=self, modal=True)
        dialog.set_program_name(APP_NAME)
        dialog.set_version(__version__)
        dialog.set_comments("A software store for LCOS and other Devuan-based systems.\n"
                            "Installs from the Devuan repositories (APT) and Flathub (Flatpak).")
        dialog.set_copyright("Copyright © 2026 BDM")
        dialog.set_license_type(Gtk.License.GPL_3_0)
        dialog.set_logo_icon_name("system-software-install")
        dialog.run()
        dialog.destroy()

    def _fix_sources(self, fix) -> None:
        if self.busy:
            return
        try:
            argv = runner.helper_command("fix-sources", fix.digest())
            diff = fix.line_diff()
        except (RuntimeError, OSError) as exc:
            self._message("Cannot prepare the change", str(exc), Gtk.MessageType.ERROR)
            return
        text = ("These lines will change. Nothing else in the files is touched, and vendor "
                "repositories are left alone:\n\n%s\n\nA copy of each file is saved under "
                "%s first, then the package lists are refreshed." % (diff, sourcesfix.BACKUP_ROOT))
        if self._confirm("Use release codenames in your Devuan sources?", text, "Apply change",
                         destructive=False):
            self._run_jobs("Updating package sources…", [argv], after=self._reload_all)

    def _install_flatpak(self) -> None:
        try:
            self._run_jobs("Installing Flatpak…", [runner.helper_command("install", "flatpak")],
                           after=self._reload_all)
        except RuntimeError as exc:
            self._message("Cannot run the helper", str(exc), Gtk.MessageType.ERROR)

    def _enable_flathub(self) -> None:
        self._run_jobs("Enabling Flathub…",
                       [flatpak_backend.add_flathub_argv(), flatpak_backend.update_appstream_argv()],
                       after=self._reload_all)

    # ------------------------------------------------------------------ job execution

    def _set_busy(self, busy: bool, text: str = "") -> None:
        self.busy = busy
        self.refresh_button.set_sensitive(not busy)
        self.update_all_button.set_sensitive(not busy)
        self._update_detail_buttons()

    def _run_jobs(self, title: str, argvs: List[List[str]], after: Optional[Callable[[], None]] = None) -> None:
        self._set_busy(True)
        self.log_buffer.set_text("")
        self.progress_label.set_text(title)
        self.progress_bar.set_fraction(0.0)
        self.progress_revealer.set_reveal_child(True)
        self._pulsing = True
        GLib.timeout_add(120, self._pulse)
        threading.Thread(target=self._jobs_thread, args=(argvs, after), daemon=True).start()

    def _pulse(self) -> bool:
        if self._pulsing:
            self.progress_bar.pulse()
        return self._pulsing

    def _jobs_thread(self, argvs: List[List[str]], after: Optional[Callable[[], None]]) -> None:
        rc = 0
        failed_argv: List[str] = []
        for argv in argvs:
            rc = runner.run(argv, lambda l: self._ui(self._on_log_line, l),
                            lambda f, t: self._ui(self._on_progress, f, t))
            if rc != 0:
                failed_argv = argv
                break
        self._ui(self._jobs_finished, rc, failed_argv, after)

    def _on_log_line(self, line: str) -> None:
        self.log_buffer.insert(self.log_buffer.get_end_iter(), line + "\n")
        mark = self.log_buffer.create_mark(None, self.log_buffer.get_end_iter(), False)
        self.log_view.scroll_to_mark(mark, 0.0, False, 0.0, 0.0)
        self.log_buffer.delete_mark(mark)

    def _on_progress(self, fraction: float, text: str) -> None:
        self._pulsing = False
        self.progress_bar.set_fraction(fraction)
        self.progress_bar.set_text(text)
        self.progress_bar.set_show_text(True)

    def _jobs_finished(self, rc: int, failed_argv: List[str], after: Optional[Callable[[], None]]) -> None:
        self._pulsing = False
        self.progress_bar.set_show_text(False)
        if rc != 0:
            self.progress_bar.set_fraction(0.0)
            self._add_infobar(Gtk.MessageType.ERROR, runner.describe_failure(failed_argv, rc))
        else:
            self.progress_bar.set_fraction(1.0)
            GLib.timeout_add_seconds(2, self._hide_progress)
        self._set_busy(False)
        if after is not None and rc == 0:
            after()
        else:
            self._refresh_states_async()

    def _hide_progress(self) -> bool:
        if not self.busy:
            self.progress_revealer.set_reveal_child(False)
        return False

    def _refresh_states_async(self) -> None:
        threading.Thread(target=self._refresh_thread, daemon=True).start()

    def _refresh_thread(self) -> None:
        try:
            if self.apt.available() and self.apt.cache is not None:
                self.apt.refresh_states(self.all_items)
            if flatpak_backend.available():
                flatpak_backend.refresh_states(self.all_items)
            self.launchers.clear()           # installs/removals change which launchers exist
            current = self.current
            if current is not None and current.source == APT and current.installed:
                self.launchers[current.key] = launcher.apt_launcher(current.ident)
        except Exception as exc:  # noqa: BLE001
            self._ui(self._add_infobar, Gtk.MessageType.ERROR, "Could not refresh package state: %s" % exc)
        self._ui(self._after_refresh)

    def _after_refresh(self) -> None:
        self._update_updates_count()
        self._populate()
        self._update_detail_buttons()

    # ------------------------------------------------------------------ dialogs

    def _message(self, title: str, text: str, kind=Gtk.MessageType.INFO) -> None:
        dialog = Gtk.MessageDialog(transient_for=self, modal=True, message_type=kind,
                                   buttons=Gtk.ButtonsType.CLOSE, text=title)
        dialog.format_secondary_text(text)
        dialog.run()
        dialog.destroy()

    def _confirm(self, title: str, text: str, ok_label: str, dangerous: bool = False,
                 destructive: bool = True) -> bool:
        dialog = Gtk.MessageDialog(
            transient_for=self, modal=True,
            message_type=Gtk.MessageType.WARNING if dangerous else Gtk.MessageType.QUESTION,
            buttons=Gtk.ButtonsType.NONE, text=title)
        dialog.format_secondary_text(text)
        dialog.add_button("Cancel", Gtk.ResponseType.CANCEL)
        button = dialog.add_button(ok_label, Gtk.ResponseType.OK)
        if destructive:
            button.get_style_context().add_class("destructive-action")
        dialog.set_default_response(Gtk.ResponseType.CANCEL)
        response = dialog.run()
        dialog.destroy()
        return response == Gtk.ResponseType.OK
