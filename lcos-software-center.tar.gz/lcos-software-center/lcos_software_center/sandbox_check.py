"""Detect whether this system can run Flatpak's sandbox.

Flatpak (via bubblewrap) needs unprivileged user namespaces. Some systems switch them
off (for example `user.max_user_namespaces = 0`), in which case Flatpak apps install
fine but refuse to start with "bwrap: Creating new namespace failed ... (ENOSPC)".
GTK-free so it can be tested without a display.
"""

import os
import shutil
import subprocess
from dataclasses import dataclass, field
from typing import Callable, List, Optional

NS_LIMITS = ("user", "mnt", "pid", "ipc", "uts", "net", "cgroup")
SYSCTL_VALUE = 15000
PERSIST_FILE = "/etc/sysctl.d/99-userns.conf"
NAMESPACE_ERRORS = (
    "creating new namespace failed",
    "no permissions to create new namespace",
    "unprivileged user namespaces",
    "setting up uid map",
    "unshare failed",
)


@dataclass
class SandboxStatus:
    ok: bool = True
    problem: str = ""
    commands: List[str] = field(default_factory=list)

    def explanation(self) -> str:
        """Plain-text message for an info bar or dialog (empty when everything is fine)."""
        if self.ok:
            return ""
        text = self.problem
        if self.commands:
            text += "\n\nTo fix it, run these in a terminal:\n" + "\n".join(self.commands)
        return text


def _read_int(path: str) -> Optional[int]:
    try:
        with open(path, "r", encoding="ascii") as fh:
            return int(fh.read().strip())
    except (OSError, ValueError):
        return None


def _probe(run: Callable, which: Callable) -> str:
    """Try to create a sandbox. Returns the error text if the failure is namespace related."""
    exe = which("bwrap")
    if exe:
        argv = [exe, "--ro-bind", "/", "/", "--unshare-user", "--unshare-pid",
                "--unshare-ipc", "--unshare-uts", "true"]
    else:
        exe = which("unshare")
        if not exe:
            return ""
        argv = [exe, "--user", "true"]
    try:
        proc = run(argv, capture_output=True, text=True, timeout=15)
    except (OSError, subprocess.SubprocessError):
        return ""
    if proc.returncode == 0:
        return ""
    err = (proc.stderr or "").strip()
    if any(marker in err.lower() for marker in NAMESPACE_ERRORS):
        return err.splitlines()[0]
    return ""


def check(proc_root: str = "/proc",
          run: Callable = subprocess.run,
          which: Callable = shutil.which) -> SandboxStatus:
    zero = [n for n in NS_LIMITS
            if _read_int(os.path.join(proc_root, "sys/user/max_%s_namespaces" % n)) == 0]
    clone_off = _read_int(os.path.join(proc_root, "sys/kernel/unprivileged_userns_clone")) == 0

    if zero or clone_off:
        settings: List[str] = []
        causes: List[str] = []
        if zero:
            keys = ["user.max_%s_namespaces" % n for n in zero]
            settings += ["%s=%d" % (k, SYSCTL_VALUE) for k in keys]
            causes.append("%s %s set to 0" % (", ".join(keys), "is" if len(keys) == 1 else "are"))
        if clone_off:
            settings.append("kernel.unprivileged_userns_clone=1")
            causes.append("kernel.unprivileged_userns_clone is 0")
        commands = [
            "sudo sysctl -w " + " ".join(settings),
            "printf '%s\\n' " + " ".join("'%s'" % s for s in settings) + " | sudo tee " + PERSIST_FILE,
        ]
        problem = ("Flatpak apps can be installed here but won't start: this system blocks the user "
                   "namespaces Flatpak's sandbox needs (%s). Re-enabling them loosens that "
                   "hardening setting." % "; ".join(causes))
        return SandboxStatus(False, problem, commands)

    detail = _probe(run, which)
    if detail:
        return SandboxStatus(
            False,
            "Flatpak apps can be installed here but may not start: the sandbox test failed (%s)." % detail,
            ["grep -H . /proc/sys/user/*"],
        )
    return SandboxStatus()
