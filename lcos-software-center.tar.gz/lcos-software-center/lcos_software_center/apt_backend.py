"""APT backend: read package data with python-apt, simulate changes with apt-get -s.

Nothing here talks to systemd, PackageKit or aptdaemon, so it works the same on
sysvinit/OpenRC/runit Devuan installs. Writes (install/remove/update) are done by
the root helper (see helper/lcos-sc-helper) via pkexec.
"""

import os
import re
import subprocess
import threading
from dataclasses import dataclass, field
from typing import Dict, Iterable, List, Optional

from . import appstream
from .categories import categorize_appstream, categorize_debtags, categorize_section
from .models import APT, Item

# Debian sections that practically never contain end-user applications.
SKIP_SECTIONS = {
    "libs", "libdevel", "oldlibs", "debug", "metapackages", "kernel", "localization",
    "fonts", "introspection", "interpreters", "python", "perl", "ruby", "javascript",
    "haskell", "ocaml", "rust", "golang", "php", "lisp", "java", "cli-mono", "zope",
}
SKIP_NAME_RE = re.compile(
    r"^(lib|python3?-|golang-|node-|php-|ruby-|r-cran-|r-bioc-|fonts-|gir1\.2-|gstreamer|linux-(image|headers|modules)|"
    r"task-|xserver-xorg-|xfonts-)|"
    r"(-dev|-dbg|-dbgsym|-doc|-docs|-data|-common|-l10n|-locale|-i18n|-plugins?|-themes?|-extras?)$"
)
# Used only when a package has no debtags: GUI applications depend on a GUI toolkit library.
# (SDL is deliberately absent: far too many command-line tools such as ffmpeg link it.)
GUI_LIB_RE = re.compile(
    r"^(libgtk-[34]-|libgtk2\.0-0|libqt5widgets5|libqt6widgets6|libwxgtk|libfltk)")

# Heuristic "this would change your init system / session manager" guard (Devuan-specific).
INIT_WARN_INSTALL = {"systemd-sysv", "systemd"}
INIT_WARN_REMOVE = {"sysvinit-core", "sysv-rc", "openrc", "runit-init", "elogind", "libpam-elogind",
                    "devuan-baseconf"}


@dataclass
class SimResult:
    install: List[str] = field(default_factory=list)
    remove: List[str] = field(default_factory=list)
    error: str = ""


def parse_simulation(output: str) -> SimResult:
    """Parse `apt-get -s` output ('Inst pkg (...)' / 'Remv pkg [...]' lines)."""
    result = SimResult()
    for line in output.splitlines():
        parts = line.split()
        if len(parts) < 2:
            continue
        if parts[0] == "Inst":
            result.install.append(parts[1])
        elif parts[0] == "Remv":
            result.remove.append(parts[1])
    return result


def init_warnings(sim: SimResult) -> List[str]:
    warnings = []
    risky_in = sorted(INIT_WARN_INSTALL.intersection(sim.install))
    risky_out = sorted(INIT_WARN_REMOVE.intersection(sim.remove))
    if risky_in:
        warnings.append("This would install %s, which can replace your init system." % ", ".join(risky_in))
    if risky_out:
        warnings.append("This would remove %s, which your system's init or session handling relies on."
                        % ", ".join(risky_out))
    return warnings


def simulate(action: str, names: Iterable[str]) -> SimResult:
    """Dry-run an install/remove (no root needed). `action` is 'install' or 'remove'."""
    if action not in ("install", "remove"):
        raise ValueError(action)
    env = dict(os.environ, LC_ALL="C")
    try:
        proc = subprocess.run(
            ["apt-get", "-s", "-q", "-y", action] + list(names),
            capture_output=True, text=True, env=env, timeout=120,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        return SimResult(error=str(exc))
    result = parse_simulation(proc.stdout)
    if proc.returncode != 0:
        lines = [l for l in (proc.stdout + "\n" + proc.stderr).splitlines() if l.startswith(("E:", "The following packages have unmet", " "))]
        result.error = "\n".join(lines[-12:]) or (proc.stderr.strip() or "apt-get could not plan this change.")
    return result


class AptBackend:
    def __init__(self) -> None:
        self.lock = threading.RLock()
        self.cache = None

    @staticmethod
    def available() -> bool:
        try:
            import apt  # noqa: F401
            return True
        except ImportError:
            return False

    def load(self, catalog: appstream.Catalog) -> List[Item]:
        import apt  # imported lazily so the rest of the app works without python-apt
        items: List[Item] = []
        with self.lock:
            self.cache = apt.Cache()
            # Without a distro AppStream catalog (Devuan today), packages that have no
            # local desktop file are classified from debtags / dependencies instead.
            use_fallback = catalog.distro_count == 0
            for pkg in self.cache:
                cand = pkg.candidate
                if cand is None:
                    continue
                name = pkg.name
                comp = catalog.by_pkg.get(name)
                if comp is not None:
                    item = Item(
                        source=APT, ident=name, name=comp.name or name,
                        summary=comp.summary or cand.summary or "",
                        description=comp.description, homepage=comp.homepage,
                        categories=categorize_appstream(comp.categories),
                        icons=appstream.icon_candidates(comp) + [name],
                        is_app=True,
                    )
                else:
                    section = cand.section or ""
                    bare = section.split("/")[-1]
                    is_app, cats = False, categorize_section(section)
                    if use_fallback and bare not in SKIP_SECTIONS and not SKIP_NAME_RE.search(name):
                        is_app, tags = self._classify(cand)
                        if tags:
                            cats = categorize_debtags(tags) or cats
                    item = Item(
                        source=APT, ident=name, name=name, summary=cand.summary or "",
                        categories=cats, icons=[name], is_app=is_app,
                    )
                item.version = cand.version
                item.installed = pkg.is_installed
                item.upgradable = bool(pkg.is_installed and pkg.is_upgradable)
                items.append(item)
        return items

    @staticmethod
    def _classify(cand):
        """Fallback when no AppStream data exists. Returns (is_gui_app, debtags string).

        Uses Debian's debtags (the 'Tag' field) when the package has them; otherwise
        falls back to "depends on a GUI toolkit library".
        """
        try:
            tags = " ".join((cand.record.get("Tag", "") or "").split())
        except Exception:  # noqa: BLE001 - python-apt raises assorted errors on odd records
            tags = ""
        if tags:
            is_app = "role::program" in tags and (
                "interface::x11" in tags or "x11::application" in tags or "uitoolkit::" in tags)
            return is_app, tags
        return AptBackend._depends_on_gui_toolkit(cand), ""

    @staticmethod
    def _depends_on_gui_toolkit(cand) -> bool:
        try:
            for dep in cand.dependencies:
                for base in getattr(dep, "or_dependencies", dep):
                    if GUI_LIB_RE.match(base.name):
                        return True
        except Exception:  # noqa: BLE001
            return False
        return False

    def details(self, item: Item) -> Item:
        with self.lock:
            if self.cache is None or item.ident not in self.cache:
                return item
            cand = self.cache[item.ident].candidate
            if cand is None:
                return item
            if not item.description:
                item.description = cand.description or ""
            item.homepage = item.homepage or cand.homepage or ""
            item.size = cand.size or 0
            item.installed_size = cand.installed_size or 0
            item.version = cand.version
        return item

    def refresh_states(self, items: Iterable[Item]) -> None:
        """Re-read installed/upgradable flags after an install, remove or update."""
        with self.lock:
            if self.cache is None:
                return
            self.cache.open(None)
            for item in items:
                if item.source != APT or item.ident not in self.cache:
                    continue
                pkg = self.cache[item.ident]
                item.installed = pkg.is_installed
                item.upgradable = bool(pkg.is_installed and pkg.is_upgradable)
                if pkg.candidate is not None:
                    item.version = pkg.candidate.version
