"""Sanity-check APT sources against Devuan's published guidance.

Devuan documents (https://www.devuan.org/os/packages) that its repositories are
exclusive: Debian, Ubuntu, Mint, etc. repositories should not be used directly,
codenames are preferred over suite names, and deb.devuan.org should be used over
plain http. This module reports deviations so the UI can show a gentle warning.

The suite-name advice only concerns *Devuan* repositories. Third-party vendor repos
(Chrome, Brave, Spotify, ...) often use a suite literally called "stable"; that is
their own release channel and is never reported.
"""

import glob
import os
import re
from dataclasses import dataclass
from typing import Dict, List, Optional

FOREIGN_MARKERS = ("debian.org", "ubuntu.com", "linuxmint.com", "launchpad", "canonical.com")
SUITE_NAMES = {"oldstable", "stable", "testing", "unstable"}
URL_RE = re.compile(r"(?P<scheme>https?|tor\+http|ftp)://(?P<host>[^/\s]+)(?P<path>/\S*)?")


@dataclass
class Issue:
    level: str      # "warning" or "info"
    text: str
    kind: str = ""  # "foreign", "suite-names" or "https-devuan"


@dataclass
class Entry:
    """One repository: the URIs and suites it names, and the file it came from."""
    path: str
    uris: List[str]
    suites: List[str]


def _read(path: str) -> List[str]:
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as fh:
            return fh.read().splitlines()
    except OSError:
        return []


def _is_devuan(uri: str) -> bool:
    """True for Devuan hosts (deb.devuan.org) and mirrors that carry /devuan/ in the path."""
    match = URL_RE.search(uri)
    if not match:
        return False
    return "devuan" in (match.group("host") + (match.group("path") or "")).lower()


def _parse_oneline(line: str, path: str) -> Optional[Entry]:
    """'deb [options] URI suite component...' -> Entry. Options may contain spaces."""
    tokens = line.split()
    if len(tokens) < 3 or tokens[0] not in ("deb", "deb-src"):
        return None
    i = 1
    if tokens[i].startswith("["):
        while i < len(tokens) and not tokens[i].endswith("]"):
            i += 1
        i += 1
    if i + 1 >= len(tokens):
        return None
    return Entry(path, [tokens[i]], [tokens[i + 1]])


def _parse_deb822(lines: List[str], path: str) -> List[Entry]:
    entries: List[Entry] = []
    block: Dict[str, str] = {}
    last = ""

    def flush() -> None:
        if "uris" in block and "suites" in block and block.get("enabled", "yes").lower() not in ("no", "false", "0"):
            entries.append(Entry(path, block["uris"].split(), block["suites"].split()))

    for raw in lines + [""]:
        if not raw.strip():
            flush()
            block, last = {}, ""
            continue
        if raw.lstrip().startswith("#"):
            continue
        if raw[0] in " \t" and last:                   # continuation of the previous field
            block[last] += " " + raw.strip()
        elif ":" in raw:
            key, _, value = raw.partition(":")
            last = key.strip().lower()
            block[last] = value.strip()
    return entries


def _load(root: str):
    """Return (entries, non-comment lines) from sources.list, *.list and *.sources."""
    entries: List[Entry] = []
    texts: List[str] = []
    one_line_files = [os.path.join(root, "etc/apt/sources.list")]
    one_line_files += sorted(glob.glob(os.path.join(root, "etc/apt/sources.list.d/*.list")))
    for path in one_line_files:
        for line in _read(path):
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            texts.append(line)
            entry = _parse_oneline(line, path)
            if entry is not None:
                entries.append(entry)
    for path in sorted(glob.glob(os.path.join(root, "etc/apt/sources.list.d/*.sources"))):
        lines = _read(path)
        texts.extend(l.strip() for l in lines if l.strip() and not l.lstrip().startswith("#"))
        entries.extend(_parse_deb822(lines, path))
    return entries, texts


def check(root: str = "/") -> List[Issue]:
    entries, texts = _load(root)
    issues: List[Issue] = []

    seen_foreign = set()
    https_devuan = False
    for line in texts:
        for match in URL_RE.finditer(line):
            host = match.group("host").lower()
            if "devuan" in host:
                if host.endswith("deb.devuan.org") and match.group("scheme") == "https":
                    https_devuan = True
                continue
            if any(marker in host for marker in FOREIGN_MARKERS):
                seen_foreign.add(host)

    suites_used = set()
    for entry in entries:
        if not any(_is_devuan(uri) for uri in entry.uris):
            continue                                   # vendor repos name their own suites
        shown = "/" + os.path.relpath(entry.path, root)
        for suite in entry.suites:
            if suite.split("-")[0] in SUITE_NAMES:
                suites_used.add("%s in %s" % (suite, shown))

    if seen_foreign:
        issues.append(Issue(
            "warning",
            "Non-Devuan repositories are configured (%s). Devuan advises against using "
            "Debian, Ubuntu or Mint repositories directly; they can pull in systemd and "
            "break your init setup." % ", ".join(sorted(seen_foreign)),
            "foreign",
        ))
    if suites_used:
        issues.append(Issue(
            "info",
            "Your Devuan sources use suite names (%s). Devuan recommends release codenames "
            "(e.g. excalibur) so a new release doesn't change your system unexpectedly."
            % ", ".join(sorted(suites_used)),
            "suite-names",
        ))
    if https_devuan:
        issues.append(Issue(
            "info",
            "deb.devuan.org is configured with https. Devuan recommends plain http there "
            "(packages are verified with OpenPGP signatures).",
            "https-devuan",
        ))
    return issues
