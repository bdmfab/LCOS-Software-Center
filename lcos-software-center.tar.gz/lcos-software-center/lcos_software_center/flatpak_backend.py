"""Flatpak backend built on the `flatpak` command line.

Flatpak performs its own authorization through polkit for system-wide installs, so
these commands run as the normal user. Set LCOS_SC_FLATPAK_SCOPE=user to install
into ~/.local/share/flatpak instead (no authentication needed).
"""

import os
import re
import shutil
import subprocess
from typing import Dict, List, Optional, Set, Tuple

from . import appstream
from .categories import categorize_appstream
from .models import FLATPAK, Item

FLATHUB_URL = "https://dl.flathub.org/repo/flathub.flatpakrepo"
COLUMNS = "application,name,description,version,origin"
# The gap between number and unit may be a space, a no-break space, or '?' when glib can't
# encode a no-break space in a non-UTF-8 locale, so accept any non-alphanumeric run there.
SIZE_RE = re.compile(r"^[<~]?\W*([0-9]+(?:\.[0-9]+)?)[^0-9A-Za-z]*(bytes?|[kKMGT]i?B)$")
SIZE_UNITS = {"B": 1, "BYTE": 1, "BYTES": 1, "KB": 1000, "MB": 1000 ** 2, "GB": 1000 ** 3, "TB": 1000 ** 4,
              "KIB": 1024, "MIB": 1024 ** 2, "GIB": 1024 ** 3, "TIB": 1024 ** 4}
C_ENV = dict(os.environ, LC_ALL="C.UTF-8")   # only for size queries: "12.3 MB" with a plain decimal point


def parse_size(text: str) -> int:
    """'12.3 MB' / '800 bytes' / '< 1 kB' (as printed by flatpak) -> bytes; 0 when unknown."""
    match = SIZE_RE.match(text.strip())
    if not match:
        return 0
    return int(float(match.group(1)) * SIZE_UNITS[match.group(2).upper()])


def scope_flag() -> str:
    return "--user" if os.environ.get("LCOS_SC_FLATPAK_SCOPE", "system").lower() == "user" else "--system"


def available() -> bool:
    return shutil.which("flatpak") is not None


def _run(argv: List[str], timeout: int = 180, env=None) -> Tuple[int, str]:
    try:
        proc = subprocess.run(argv, capture_output=True, text=True, timeout=timeout, env=env)
    except (OSError, subprocess.TimeoutExpired):
        return 127, ""
    return proc.returncode, proc.stdout


def parse_remote_ls(text: str) -> List[Dict[str, str]]:
    """Parse tab-separated `flatpak remote-ls --columns=application,name,description,version,origin`."""
    rows = []
    for line in text.splitlines():
        cols = line.split("\t")
        if len(cols) < 2 or not cols[0].strip() or "." not in cols[0]:
            continue
        cols += [""] * (5 - len(cols))
        rows.append({
            "id": cols[0].strip(), "name": cols[1].strip(), "summary": cols[2].strip(),
            "version": cols[3].strip(), "origin": cols[4].strip() or "flathub",
        })
    return rows


def remotes() -> List[str]:
    rc, out = _run(["flatpak", "remotes", "--columns=name"], timeout=30)
    return [l.strip() for l in out.splitlines() if l.strip()] if rc == 0 else []


def _installed_ids() -> Set[str]:
    rc, out = _run(["flatpak", "list", "--app", "--columns=application"], timeout=60)
    return {l.strip() for l in out.splitlines() if l.strip()} if rc == 0 else set()


def parse_size_table(text: str) -> Dict[str, Tuple[int, int]]:
    """Tab-separated 'application, download-size, installed-size' -> {id: (download, installed)}."""
    table: Dict[str, Tuple[int, int]] = {}
    for line in text.splitlines():
        cols = line.split("\t") + ["", ""]
        if cols[0].strip() and "." in cols[0]:
            table[cols[0].strip()] = (parse_size(cols[1]), parse_size(cols[2]))
    return table


def _remote_sizes() -> Dict[str, Tuple[int, int]]:
    rc, out = _run(["flatpak", "remote-ls", "--app", "--columns=application,download-size,installed-size"],
                   env=C_ENV)
    return parse_size_table(out) if rc == 0 else {}   # older flatpak without these columns: no sizes


def _installed_sizes() -> Dict[str, int]:
    """On-disk size of installed apps, as a fallback when the remote doesn't list one."""
    rc, out = _run(["flatpak", "list", "--app", "--columns=application,size"], timeout=60, env=C_ENV)
    sizes: Dict[str, int] = {}
    if rc == 0:
        for line in out.splitlines():
            ident, _, size = line.partition("\t")
            if ident.strip():
                sizes[ident.strip()] = parse_size(size)
    return sizes


def _updatable_ids() -> Set[str]:
    rc, out = _run(["flatpak", "remote-ls", "--updates", "--app", "--columns=application"], timeout=60)
    return {l.strip() for l in out.splitlines() if l.strip()} if rc == 0 else set()


def load(catalog: appstream.Catalog) -> Tuple[List[Item], Dict[str, bool]]:
    """Return (items, state) where state = {'installed': bool, 'has_remote': bool}."""
    state = {"installed": available(), "has_remote": False}
    if not state["installed"]:
        return [], state
    state["has_remote"] = bool(remotes())
    if not state["has_remote"]:
        return [], state

    rc, out = _run(["flatpak", "remote-ls", "--app", "--columns=" + COLUMNS])
    rows = parse_remote_ls(out) if rc == 0 else []
    if not rows:  # older flatpak without the 'origin' column
        rc, out = _run(["flatpak", "remote-ls", "--app", "--columns=application,name,description,version"])
        rows = parse_remote_ls(out) if rc == 0 else []

    installed = _installed_ids()
    updatable = _updatable_ids()
    remote_sizes = _remote_sizes()
    local_sizes = _installed_sizes() if installed else {}
    seen: Set[str] = set()
    items: List[Item] = []
    for row in rows:
        if row["id"] in seen:
            continue
        seen.add(row["id"])
        comp = catalog.by_id.get(row["id"])
        item = Item(
            source=FLATPAK, ident=row["id"], name=row["name"] or row["id"],
            summary=row["summary"], version=row["version"], origin=row["origin"],
            installed=row["id"] in installed, upgradable=row["id"] in updatable,
            size=remote_sizes.get(row["id"], (0, 0))[0],
            installed_size=remote_sizes.get(row["id"], (0, 0))[1] or local_sizes.get(row["id"], 0),
        )
        if comp is not None:
            item.name = comp.name or item.name
            item.summary = comp.summary or item.summary
            item.description = comp.description
            item.homepage = comp.homepage
            item.categories = categorize_appstream(comp.categories)
            item.icons = appstream.icon_candidates(comp) + [row["id"]]
        else:
            item.categories = ["other"]
            item.icons = [row["id"]]
        items.append(item)
    return items, state


def refresh_states(items: List[Item]) -> None:
    installed = _installed_ids()
    updatable = _updatable_ids()
    for item in items:
        if item.source == FLATPAK:
            item.installed = item.ident in installed
            item.upgradable = item.ident in updatable


# --- command builders (the UI runs these through runner.run) -------------------------

def install_argv(item: Item) -> List[str]:
    return ["flatpak", "install", scope_flag(), "-y", "--noninteractive", item.origin or "flathub", item.ident]


def remove_argv(item: Item) -> List[str]:
    return ["flatpak", "uninstall", scope_flag(), "-y", "--noninteractive", item.ident]


def update_argv(item: Optional[Item] = None) -> List[str]:
    argv = ["flatpak", "update", scope_flag(), "-y", "--noninteractive"]
    if item is not None:
        argv.append(item.ident)
    return argv


def add_flathub_argv() -> List[str]:
    return ["flatpak", "remote-add", scope_flag(), "--if-not-exists", "flathub", FLATHUB_URL]


def update_appstream_argv() -> List[str]:
    return ["flatpak", "update", scope_flag(), "--appstream", "-y", "--noninteractive"]
