"""User-chosen colours for the header, the side panel and the main panel.

GTK-free logic: loading/saving the settings file and turning the settings into CSS.
Only strict "#rrggbb" values are ever accepted, so nothing else can reach the CSS.
Each region has a background colour and a text colour; with no text colour chosen
("auto") black or white is picked for readability against the background.
"""

import json
import os
import re
import tempfile
from typing import Dict, Optional

REGIONS = ("header", "sidebar", "main")
REGION_LABELS = {"header": "Header", "sidebar": "Side panel", "main": "Main panel"}
HEX_RE = re.compile(r"^#[0-9a-fA-F]{6}$")

# {"header": {"bg": "#2b5797", "fg": None}, ...}; a missing region means "system theme".
Settings = Dict[str, Dict[str, Optional[str]]]


def config_path() -> str:
    base = os.environ.get("XDG_CONFIG_HOME") or os.path.join(os.path.expanduser("~"), ".config")
    return os.path.join(base, "lcos-software-center", "theme.json")


def valid_hex(value) -> bool:
    return isinstance(value, str) and bool(HEX_RE.match(value))


def clean(raw) -> Settings:
    """Keep only well-formed entries from whatever was read from disk."""
    result: Settings = {}
    if not isinstance(raw, dict):
        return result
    for region in REGIONS:
        entry = raw.get(region)
        if isinstance(entry, dict) and valid_hex(entry.get("bg")):
            fg = entry.get("fg")
            result[region] = {"bg": entry["bg"].lower(), "fg": fg.lower() if valid_hex(fg) else None}
    return result


def load(path: Optional[str] = None) -> Settings:
    try:
        with open(path or config_path(), "r", encoding="utf-8") as fh:
            return clean(json.load(fh))
    except (OSError, ValueError):
        return {}


def save(settings: Settings, path: Optional[str] = None) -> None:
    path = path or config_path()
    os.makedirs(os.path.dirname(path), exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=os.path.dirname(path), prefix=".theme-")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            json.dump(clean(settings), fh, indent=2)
            fh.write("\n")
        os.replace(tmp, path)
    except BaseException:
        if os.path.exists(tmp):
            os.unlink(tmp)
        raise


def _luminance(color: str) -> float:
    def channel(i: int) -> float:
        c = int(color[1 + 2 * i:3 + 2 * i], 16) / 255.0
        return c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4
    return 0.2126 * channel(0) + 0.7152 * channel(1) + 0.0722 * channel(2)


def contrast(a: str, b: str) -> float:
    la, lb = sorted((_luminance(a), _luminance(b)), reverse=True)
    return (la + 0.05) / (lb + 0.05)


def readable_text(bg: str) -> str:
    """Black or white, whichever contrasts more with `bg`."""
    return "#000000" if contrast(bg, "#000000") >= contrast(bg, "#ffffff") else "#ffffff"


def effective_fg(entry: Dict[str, Optional[str]]) -> str:
    return entry.get("fg") or readable_text(entry["bg"])


def build_css(settings: Settings) -> str:
    """CSS for the regions in `settings`; empty string when nothing is customised."""
    settings = clean(settings)
    rules = []
    if "header" in settings:
        bg, fg = settings["header"]["bg"], effective_fg(settings["header"])
        rules.append(
            "headerbar.lcos-header { background-image: none; background-color: %(bg)s; }\n"
            "headerbar.lcos-header label, headerbar.lcos-header button.titlebutton { color: %(fg)s; }" % locals())
    if "sidebar" in settings:
        bg, fg = settings["sidebar"]["bg"], effective_fg(settings["sidebar"])
        rules.append(
            ".lcos-sidebar, .lcos-sidebar scrolledwindow, .lcos-sidebar list, .lcos-sidebar row,\n"
            ".lcos-sidebar separator { background-image: none; background-color: %(bg)s; color: %(fg)s; }\n"
            ".lcos-sidebar label, .lcos-sidebar checkbutton { color: %(fg)s; }\n"
            ".lcos-sidebar row:selected, .lcos-sidebar row:selected label "
            "{ background-color: @theme_selected_bg_color; color: @theme_selected_fg_color; }" % locals())
    if "main" in settings:
        bg, fg = settings["main"]["bg"], effective_fg(settings["main"])
        rules.append(
            ".lcos-main, .lcos-main box, .lcos-main scrolledwindow, .lcos-main viewport, .lcos-main treeview.view,\n"
            ".lcos-main textview text, .lcos-main grid { background-image: none; background-color: %(bg)s; "
            "color: %(fg)s; }\n"
            ".lcos-main label { color: inherit; }\n"
            ".lcos-main treeview.view:selected, .lcos-main treeview.view:selected:focus "
            "{ background-color: @theme_selected_bg_color; color: @theme_selected_fg_color; }" % locals())
    return "\n".join(rules)
