"""Launching installed applications from the store (GTK-free so it can be tested)."""

import fnmatch
import os
import subprocess
from typing import Callable, Iterable, List, Optional

from . import localmeta
from .models import APT, FLATPAK, Item

APP_DIR = "/usr/share/applications/"


def _dpkg_files(package: str) -> List[str]:
    try:
        proc = subprocess.run(["dpkg", "-L", package], capture_output=True, text=True, timeout=30)
    except (OSError, subprocess.TimeoutExpired):
        return []
    return proc.stdout.splitlines() if proc.returncode == 0 else []


def apt_launcher(package: str,
                 lister: Optional[Callable[[str], Iterable[str]]] = None,
                 app_dir: str = APP_DIR) -> Optional[str]:
    """Path of the first visible .desktop launcher shipped by an installed package, or None."""
    files = (lister or _dpkg_files)(package)
    for path in files:
        path = path.strip()
        if not (path.startswith(app_dir) and fnmatch.fnmatch(path, "*.desktop")):
            continue
        if localmeta.parse_desktop(path) is not None:       # skips NoDisplay/Hidden/non-applications
            return path
    return None


def flatpak_run_argv(item: Item) -> List[str]:
    return ["flatpak", "run", item.ident]


def launch_flatpak(item: Item) -> Optional[str]:
    """Start a Flatpak app detached from the store. Returns an error message or None."""
    try:
        subprocess.Popen(flatpak_run_argv(item), stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                         stderr=subprocess.DEVNULL, start_new_session=True)
    except OSError as exc:
        return "Could not start %s: %s" % (item.name, exc)
    return None
