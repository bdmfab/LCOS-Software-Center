"""Run package-management commands, stream their output, and parse progress.

GTK-free on purpose so it can be tested without a display.
"""

import os
import re
import subprocess
from typing import Callable, List, Optional, Tuple

from . import paths

PERCENT_RE = re.compile(r"(\d{1,3})\s*%")
PKEXEC_CANCELLED = (126, 127)


def helper_command(*args: str) -> List[str]:
    """Command line that runs the root helper (through pkexec when not already root)."""
    helper = paths.find_helper()
    if helper is None:
        raise RuntimeError("lcos-sc-helper not found. Run `make install` or set LCOS_SC_HELPER.")
    if os.geteuid() == 0:
        return [helper, *args]
    return ["pkexec", helper, *args]


def parse_progress(line: str) -> Optional[Tuple[float, str]]:
    """Return (fraction 0..1, label) for a progress line, else None.

    Understands apt's machine-readable `APT::Status-Fd` lines
    (`pmstatus:<pkg>:<percent>:<text>` and `dlstatus:<n>:<percent>:<text>`) and any
    line containing a percentage (flatpak, dpkg).
    """
    line = line.strip()
    if line.startswith(("pmstatus:", "dlstatus:")):
        parts = line.split(":", 3)
        if len(parts) >= 3:
            try:
                pct = float(parts[2])
            except ValueError:
                return None
            text = parts[3].strip() if len(parts) > 3 else ""
            if not text:
                text = "Downloading" if parts[0] == "dlstatus" else "Installing"
            return max(0.0, min(pct / 100.0, 1.0)), text
        return None
    match = PERCENT_RE.search(line)
    if match:
        pct = int(match.group(1))
        if 0 <= pct <= 100:
            return pct / 100.0, line[:80]
    return None


def is_status_line(line: str) -> bool:
    return line.startswith(("pmstatus:", "dlstatus:"))


def run(argv: List[str],
        on_line: Callable[[str], None],
        on_progress: Callable[[float, str], None]) -> int:
    """Run argv, calling back for each output line. Returns the exit code."""
    env = dict(os.environ, LC_ALL="C.UTF-8")
    try:
        proc = subprocess.Popen(
            argv, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            text=True, bufsize=1, env=env,
        )
    except OSError as exc:
        on_line("Could not start %s: %s" % (argv[0], exc))
        return 127
    assert proc.stdout is not None
    with proc.stdout:
        for raw in proc.stdout:       # text mode turns '\r' progress updates into lines too
            line = raw.rstrip("\n")
            if not line:
                continue
            progress = parse_progress(line)
            if progress is not None:
                on_progress(*progress)
            if not is_status_line(line):
                on_line(line)
    return proc.wait()


def describe_failure(argv: List[str], rc: int) -> str:
    if argv and argv[0] == "pkexec" and rc in PKEXEC_CANCELLED:
        return "Authentication was cancelled or failed, so nothing was changed."
    if argv and argv[-2:-1] and "fix-sources" in argv and rc in (3, 4):
        return "The sources were not changed (the safety checks refused it). Expand 'Details' for the reason."
    return "The operation failed (exit code %d). Expand 'Details' for the full output." % rc
