"""Locating the privileged helper and bundled data files (dev checkout or installed)."""

import json
import os
from typing import List, Optional

REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
INSTALLED_DATA_DIR = "/usr/share/lcos-software-center"
HELPER_NAME = "lcos-sc-helper"


def find_helper() -> Optional[str]:
    candidates = [
        os.environ.get("LCOS_SC_HELPER", ""),
        "/usr/libexec/lcos-software-center/" + HELPER_NAME,
        "/usr/local/libexec/lcos-software-center/" + HELPER_NAME,
        os.path.join(REPO_ROOT, "helper", HELPER_NAME),
    ]
    for path in candidates:
        if path and os.path.isfile(path) and os.access(path, os.X_OK):
            return os.path.realpath(path)
    return None


def find_data_file(name: str) -> Optional[str]:
    for base in (os.path.join(REPO_ROOT, "data"), INSTALLED_DATA_DIR):
        path = os.path.join(base, name)
        if os.path.isfile(path):
            return path
    return None


def load_featured() -> dict:
    """Curated 'Featured' lists: {"apt": [package names], "flatpak": [app ids]}."""
    path = find_data_file("featured.json")
    if not path:
        return {"apt": [], "flatpak": []}
    try:
        with open(path, "r", encoding="utf-8") as fh:
            data = json.load(fh)
    except (OSError, ValueError):
        return {"apt": [], "flatpak": []}
    return {
        "apt": [str(x) for x in data.get("apt", [])],
        "flatpak": [str(x) for x in data.get("flatpak", [])],
    }
