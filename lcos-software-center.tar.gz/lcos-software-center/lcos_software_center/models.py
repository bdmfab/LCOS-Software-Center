"""Shared data model used by the backends and the UI."""

from dataclasses import dataclass, field
from typing import List

APT = "apt"
FLATPAK = "flatpak"

SOURCE_LABELS = {APT: "APT", FLATPAK: "Flatpak"}


@dataclass
class Item:
    source: str                     # APT or FLATPAK
    ident: str                      # apt package name or flatpak application id
    name: str
    summary: str = ""
    description: str = ""
    version: str = ""
    installed: bool = False
    upgradable: bool = False
    categories: List[str] = field(default_factory=list)   # keys from categories.py
    icons: List[str] = field(default_factory=list)        # absolute paths and/or theme names
    homepage: str = ""
    size: int = 0                   # download size in bytes (0 = unknown)
    installed_size: int = 0         # bytes (0 = unknown)
    origin: str = ""                # flatpak remote name
    is_app: bool = True             # False = library/dev/data package (hidden by default)
    featured: bool = False

    @property
    def key(self) -> str:
        return "%s:%s" % (self.source, self.ident)

    @property
    def source_label(self) -> str:
        return SOURCE_LABELS.get(self.source, self.source)


def human_size(num: int) -> str:
    if not num:
        return "unknown"
    value = float(num)
    for unit in ("B", "kB", "MB", "GB"):
        if value < 1000 or unit == "GB":
            return ("%d %s" % (value, unit)) if unit == "B" else ("%.1f %s" % (value, unit))
        value /= 1000.0
    return "%d B" % num
