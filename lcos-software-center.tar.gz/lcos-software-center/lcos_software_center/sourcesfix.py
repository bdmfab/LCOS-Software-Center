"""Replace suite names ("stable") with release codenames in Devuan APT sources.

Devuan recommends codenames (excalibur, daedalus, ...) over suite names so that a new
release doesn't change your system unexpectedly (https://www.devuan.org/os/packages).

The unprivileged GUI builds a *plan* to show a preview; the root helper
(lcos-sc-helper fix-sources) rebuilds the same plan itself and applies it.

Design rules, because this edits system configuration:

* The new name is never guessed. It is the Codename that the repository's own Release
  file (already downloaded by `apt update`) reports for that exact suite, so the change
  keeps pointing at what apt already resolves today.
* Only Devuan repositories are touched; vendor repos (Chrome, Brave, ...) are left alone.
* If the system's /etc/os-release names a known Devuan release that differs from what the
  suite resolves to (a release upgrade may be in progress), nothing is changed.
* Every file is backed up first and rewritten atomically; only the suite word changes.
"""

import datetime
import glob
import hashlib
import os
import re
import shutil
import tempfile
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

from . import repocheck

KNOWN_CODENAMES = {"jessie", "ascii", "beowulf", "chimaera", "daedalus", "excalibur", "freia", "ceres"}
BACKUP_ROOT = "/var/backups/lcos-software-center"
CODENAME_RE = re.compile(r"^[a-z][a-z0-9]*(-[a-z0-9]+)*$")
TOKEN_RE = re.compile(r"\S+")


@dataclass
class Change:
    path: str
    old: str
    new: str


@dataclass
class FixPlan:
    changes: List[Change] = field(default_factory=list)
    problems: List[str] = field(default_factory=list)
    installed_codename: str = ""

    def can_apply(self) -> bool:
        return bool(self.changes) and not self.problems

    def preview(self, root: str = "/") -> str:
        return "\n".join("  %s -> %s   (%s)" % (c.old, c.new, "/" + os.path.relpath(c.path, root))
                         for c in self.changes)

    def digest(self, root: str = "/") -> str:
        """Fingerprint of exactly what would change; the helper refuses if its own plan differs."""
        text = "\n".join("%s\t%s\t%s" % (os.path.relpath(c.path, root), c.old, c.new) for c in self.changes)
        return hashlib.sha256(text.encode("utf-8")).hexdigest()

    def line_diff(self, root: str = "/") -> str:
        """The exact lines that would change, as '-' / '+' pairs grouped by file."""
        by_file: Dict[str, Dict[str, str]] = {}
        for c in self.changes:
            by_file.setdefault(c.path, {})[c.old] = c.new
        out: List[str] = []
        for path, mapping in sorted(by_file.items()):
            with open(path, "r", encoding="utf-8", newline="") as fh:
                old_text = fh.read()
            new_text, _ = (rewrite_deb822 if path.endswith(".sources") else rewrite_oneline)(old_text, mapping)
            out.append("/" + os.path.relpath(path, root) + ":")
            for before, after in zip(old_text.splitlines(), new_text.splitlines()):
                if before != after:
                    out.append("  - " + before.strip())
                    out.append("  + " + after.strip())
        return "\n".join(out)

    def summary(self, root: str = "/") -> str:
        parts = []
        if self.installed_codename:
            parts.append("This system reports release '%s'." % self.installed_codename)
        if self.changes:
            parts.append("Your configured repositories currently resolve these names:\n" + self.preview(root))
        parts.extend(self.problems)
        return "\n".join(parts)


# ---------------------------------------------------------------------------- parsing

def installed_codename(root: str = "/") -> str:
    for line in repocheck._read(os.path.join(root, "etc/os-release")):
        key, _, value = line.partition("=")
        if key.strip() == "VERSION_CODENAME":
            return value.strip().strip("\"'").lower()
    return ""


def source_files(root: str = "/") -> List[str]:
    base = os.path.join(root, "etc/apt")
    return ([os.path.join(base, "sources.list")]
            + sorted(glob.glob(os.path.join(base, "sources.list.d/*.list")))
            + sorted(glob.glob(os.path.join(base, "sources.list.d/*.sources"))))


def _one_line(line: str):
    """(uri, suite, (start, end)) of the suite token on an active 'deb ...' line, else None."""
    if not line.strip() or line.lstrip().startswith("#"):
        return None
    toks = [(m.group(), m.start(), m.end()) for m in TOKEN_RE.finditer(line)]
    if len(toks) < 3 or toks[0][0] not in ("deb", "deb-src"):
        return None
    i = 1
    if toks[i][0].startswith("["):
        while i < len(toks) and not toks[i][0].endswith("]"):
            i += 1
        i += 1
    if i + 1 >= len(toks):
        return None
    return toks[i][0], toks[i + 1][0], (toks[i + 1][1], toks[i + 1][2])


def _deb822_stanzas(lines: List[str]) -> List[dict]:
    """Stanzas with their URIs, suites and the line indexes holding the Suites field."""
    stanzas: List[dict] = []
    cur: Optional[dict] = None
    last = ""
    for idx, raw in enumerate(list(lines) + [""]):
        if not raw.strip():
            if cur is not None:
                stanzas.append(_finish(cur))
                cur, last = None, ""
            continue
        if raw.lstrip().startswith("#"):
            continue
        if cur is None:
            cur = {"fields": {}, "lines": {}}
        if raw[0] in " \t" and last:
            cur["fields"][last] += " " + raw.strip()
            cur["lines"][last].append(idx)
        elif ":" in raw:
            key, _, value = raw.partition(":")
            last = key.strip().lower()
            cur["fields"][last] = value.strip()
            cur["lines"][last] = [idx]
    return stanzas


def _finish(cur: dict) -> dict:
    fields = cur["fields"]
    return {
        "uris": fields.get("uris", "").split(),
        "suites": fields.get("suites", "").split(),
        "suite_lines": cur["lines"].get("suites", []),
        "enabled": fields.get("enabled", "yes").lower() not in ("no", "false", "0"),
    }


def _file_entries(path: str) -> List[Tuple[List[str], List[str]]]:
    lines = repocheck._read(path)
    if path.endswith(".sources"):
        return [(s["uris"], s["suites"]) for s in _deb822_stanzas(lines) if s["enabled"]]
    entries = []
    for line in lines:
        parsed = _one_line(line)
        if parsed:
            entries.append(([parsed[0]], [parsed[1]]))
    return entries


def release_codename(root: str, uri: str, suite: str) -> Optional[str]:
    """Codename from the Release file apt downloaded for this repository and suite."""
    key = re.sub(r"^[a-z+]+://", "", uri).rstrip("/").replace("/", "_")
    base = os.path.join(root, "var/lib/apt/lists", "%s_dists_%s_" % (key, suite))
    for name in ("InRelease", "Release"):
        for line in repocheck._read(base + name):
            if line.startswith("-----BEGIN PGP SIGNATURE"):
                break
            if line.startswith("Codename:"):
                return line.partition(":")[2].strip().lower() or None
    return None


# ---------------------------------------------------------------------------- planning

def plan(root: str = "/") -> FixPlan:
    result = FixPlan(installed_codename=installed_codename(root))
    problems: List[str] = []
    for path in source_files(root):
        mapping: Dict[str, str] = {}
        for uris, suites in _file_entries(path):
            devuan = [u for u in uris if repocheck._is_devuan(u)]
            if not devuan:
                continue                                 # vendor repository: not ours to touch
            for suite in suites:
                if suite.split("-")[0] not in repocheck.SUITE_NAMES:
                    continue
                codename = release_codename(root, devuan[0], suite)
                if codename is None:
                    problems.append("No release information is stored yet for '%s' (%s). "
                                    "Run 'sudo apt update', then try again." % (suite, devuan[0]))
                elif not CODENAME_RE.match(codename) or codename.split("-")[0] in repocheck.SUITE_NAMES:
                    problems.append("The repository reports an unusable codename '%s' for '%s'." % (codename, suite))
                elif mapping.setdefault(suite, codename) != codename:
                    problems.append("'%s' resolves to different releases in %s; edit it by hand." % (suite, path))
        result.changes.extend(Change(path, old, new) for old, new in sorted(mapping.items()))

    installed = result.installed_codename
    if installed in KNOWN_CODENAMES:
        for change in result.changes:
            resolved = change.new.split("-")[0]
            if resolved != installed:
                problems.append(
                    "This system reports release '%s', but '%s' currently points to '%s'. You may be "
                    "part-way through a release upgrade, so no automatic change is offered. Edit the "
                    "file by hand with the release you want." % (installed, change.old, resolved))
                break
    result.problems = sorted(set(problems))
    return result


def advice(fix: FixPlan, root: str = "/") -> str:
    """One-paragraph explanation for the info bar, naming the real release and the file."""
    if fix.can_apply():
        steps = "; ".join("replace `%s` with `%s` in `%s`" % (c.old, c.new, "/" + os.path.relpath(c.path, root))
                          for c in fix.changes)
        who = "Your system is `%s`, and your repositories currently resolve to it. " % fix.installed_codename \
            if fix.installed_codename else ""
        return who + "To use codenames: " + steps + ". 'Fix it' shows the exact lines first."
    if fix.problems:
        return "No automatic fix is offered: " + " ".join(fix.problems)
    return ""


# ---------------------------------------------------------------------------- rewriting

def _swap(text: str, mapping: Dict[str, str]) -> str:
    return TOKEN_RE.sub(lambda m: mapping.get(m.group(), m.group()), text)


def rewrite_oneline(text: str, mapping: Dict[str, str]) -> Tuple[str, int]:
    out: List[str] = []
    count = 0
    for raw in text.splitlines(keepends=True):
        body = raw.rstrip("\r\n")
        eol = raw[len(body):]
        parsed = _one_line(body)
        if parsed:
            uri, suite, (start, end) = parsed
            if suite in mapping and repocheck._is_devuan(uri):
                body = body[:start] + mapping[suite] + body[end:]
                count += 1
        out.append(body + eol)
    return "".join(out), count


def rewrite_deb822(text: str, mapping: Dict[str, str]) -> Tuple[str, int]:
    lines = text.splitlines(keepends=True)
    count = 0
    for stanza in _deb822_stanzas([l.rstrip("\r\n") for l in lines]):
        if not any(repocheck._is_devuan(u) for u in stanza["uris"]):
            continue
        for n, idx in enumerate(stanza["suite_lines"]):
            raw = lines[idx]
            if n == 0:                                   # keep the 'Suites:' field name untouched
                head, sep, tail = raw.partition(":")
                new = head + sep + _swap(tail, mapping)
            else:
                new = _swap(raw, mapping)
            if new != raw:
                lines[idx] = new
                count += 1
    return "".join(lines), count


def apply(fix: FixPlan, root: str = "/", backup_root: str = BACKUP_ROOT,
          now: Optional[datetime.datetime] = None) -> Tuple[str, List[str]]:
    """Back up and rewrite the files in `fix`. Returns (backup_dir, changed_files)."""
    by_file: Dict[str, Dict[str, str]] = {}
    for change in fix.changes:
        by_file.setdefault(change.path, {})[change.old] = change.new
    stamp = (now or datetime.datetime.now()).strftime("%Y%m%d-%H%M%S")
    backup_dir = os.path.join(backup_root if root == "/" else os.path.join(root, backup_root.lstrip("/")), stamp)

    changed: List[str] = []
    for path, mapping in sorted(by_file.items()):
        with open(path, "r", encoding="utf-8", newline="") as fh:
            text = fh.read()
        new_text, count = (rewrite_deb822 if path.endswith(".sources") else rewrite_oneline)(text, mapping)
        if count == 0:
            continue
        os.makedirs(backup_dir, exist_ok=True)
        dest = os.path.join(backup_dir, os.path.basename(path))
        suffix = 0
        while os.path.exists(dest):
            suffix += 1
            dest = os.path.join(backup_dir, "%s.%d" % (os.path.basename(path), suffix))
        shutil.copy2(path, dest)

        path = os.path.realpath(path)                      # edit the target of a symlink, not the link
        st = os.stat(path)
        fd, tmp = tempfile.mkstemp(dir=os.path.dirname(path), prefix=".lcos-")
        try:
            with os.fdopen(fd, "w", encoding="utf-8", newline="") as fh:
                fh.write(new_text)
                fh.flush()
                os.fsync(fh.fileno())
            os.chmod(tmp, st.st_mode & 0o7777)
            try:
                os.chown(tmp, st.st_uid, st.st_gid)
            except OSError:
                pass                                       # not root (tests); owner stays as created
            os.replace(tmp, path)
        except BaseException:
            if os.path.exists(tmp):
                os.unlink(tmp)
            raise
        changed.append(path)
    return (backup_dir if changed else ""), changed
