"""Application entry point."""

import sys


def main(argv=None) -> int:
    try:
        import gi
        gi.require_version("Gtk", "3.0")
        from gi.repository import Gtk
    except (ImportError, ValueError) as exc:
        print("LCOS Software Center needs GTK 3 and PyGObject: %s\n"
              "Install them with: sudo apt install python3-gi gir1.2-gtk-3.0" % exc, file=sys.stderr)
        return 1

    from . import APP_ID
    from .ui import SoftwareCenterWindow

    class Application(Gtk.Application):
        def __init__(self):
            super().__init__(application_id=APP_ID)

        def do_activate(self):
            window = self.props.active_window or SoftwareCenterWindow(self)
            window.present()

    return Application().run(argv if argv is not None else sys.argv)


if __name__ == "__main__":
    sys.exit(main())
