"""Sidebar categories and the mapping from AppStream / Debian metadata onto them."""

# (key, label, icon-theme name)
VIEWS = [
    ("all", "All applications", "view-grid-symbolic"),
    ("featured", "Featured", "starred-symbolic"),
    ("installed", "Installed", "emblem-ok-symbolic"),
    ("updates", "Updates", "software-update-available-symbolic"),
]

CATEGORIES = [
    ("internet", "Internet", "applications-internet"),
    ("office", "Office", "applications-office"),
    ("graphics", "Graphics", "applications-graphics"),
    ("multimedia", "Sound & Video", "applications-multimedia"),
    ("games", "Games", "applications-games"),
    ("development", "Programming", "applications-development"),
    ("education", "Education", "applications-education"),
    ("science", "Science", "applications-science"),
    ("accessories", "Accessories", "applications-accessories"),
    ("system", "System Tools", "applications-system"),
    ("other", "Other", "applications-other"),
]

# freedesktop.org menu categories -> our category key. Order matters only for display.
_APPSTREAM_RULES = [
    ("internet", {"Network", "WebBrowser", "Email", "Chat", "InstantMessaging", "IRCClient",
                  "FileTransfer", "P2P", "News", "RemoteAccess", "Feed", "VideoConference"}),
    ("office", {"Office", "WordProcessor", "Spreadsheet", "Presentation", "Calendar",
                "ContactManagement", "Finance", "Publishing", "Database", "Dictionary"}),
    ("graphics", {"Graphics", "2DGraphics", "3DGraphics", "RasterGraphics", "VectorGraphics",
                  "Photography", "Scanning", "OCR", "Viewer"}),
    ("multimedia", {"AudioVideo", "Audio", "Video", "Player", "Recorder", "Music", "Midi",
                    "Mixer", "Sequencer", "AudioVideoEditing", "TV", "Tuner", "DiscBurning"}),
    ("games", {"Game", "ActionGame", "AdventureGame", "ArcadeGame", "BoardGame", "BlocksGame",
               "CardGame", "LogicGame", "RolePlaying", "Shooter", "Simulation", "SportsGame",
               "StrategyGame", "Emulator"}),
    ("development", {"Development", "IDE", "Debugger", "Profiling", "RevisionControl",
                     "WebDevelopment", "GUIDesigner", "Building", "Translation"}),
    ("education", {"Education", "Languages", "ArtificialIntelligence", "Literature",
                   "Sports", "Geography", "History"}),
    ("science", {"Science", "Math", "Astronomy", "Biology", "Chemistry", "Physics",
                 "Geology", "Electronics", "Engineering", "DataVisualization", "NumericalAnalysis",
                 "MedicalSoftware", "ParallelComputing", "Robotics"}),
    ("accessories", {"Utility", "Accessibility", "Archiving", "Compression", "TextEditor",
                     "Calculator", "Clock", "FileManager", "TextTools", "Documentation"}),
    ("system", {"System", "Settings", "Monitor", "PackageManager", "Security", "TerminalEmulator",
                "FileTools", "Filesystem", "HardwareSettings", "DesktopSettings", "Printing"}),
]

# Debian "Section" field -> our category key (prefix like "contrib/" is stripped first).
_SECTION_MAP = {
    "web": "internet", "net": "internet", "mail": "internet", "comm": "internet",
    "news": "internet", "hamradio": "internet",
    "graphics": "graphics", "gnome": "system", "kde": "system", "xfce": "system",
    "sound": "multimedia", "video": "multimedia",
    "games": "games",
    "devel": "development", "vcs": "development", "debug": "development",
    "science": "science", "math": "science", "electronics": "science",
    "education": "education",
    "editors": "accessories", "text": "accessories", "utils": "accessories",
    "misc": "accessories", "doc": "accessories", "shells": "accessories",
    "admin": "system", "x11": "system", "otherosfs": "system", "kernel": "system",
    "tex": "office", "gnu-r": "science",
}


# Debian debtags (the "Tag:" field in Packages) -> our category key. Prefix match.
# This is a heuristic used only when no AppStream/desktop-file data exists.
_DEBTAG_RULES = [
    ("internet", ("web::browser", "mail::", "net::", "network::client", "use::browsing",
                  "use::chatting", "use::downloading", "protocol::bittorrent")),
    ("office", ("office::", "use::organizing", "use::typesetting")),
    ("graphics", ("works-with::image", "works-with::3dmodel", "use::painting")),
    ("multimedia", ("sound::", "tv::", "works-with::audio", "works-with::video",
                    "use::playing", "use::synthesis")),
    ("games", ("game::",)),
    ("development", ("devel::", "use::compiling")),
    ("education", ("use::learning", "education::")),
    ("science", ("field::mathematics", "field::physics", "field::astronomy", "field::biology",
                 "field::chemistry", "field::geology", "field::medicine", "field::statistics",
                 "biology::")),
    ("accessories", ("works-with::text", "use::calculating", "works-with::archive")),
    ("system", ("admin::", "hardware::", "security::", "use::configuring", "use::monitor")),
]


def categorize_debtags(tags):
    """Category keys for a debtags string such as 'role::program, game::puzzle'. [] if none match."""
    tag_list = [t for t in (tags or "").replace(",", " ").split() if t]
    keys = []
    for key, prefixes in _DEBTAG_RULES:
        if any(tag.startswith(prefix) for tag in tag_list for prefix in prefixes):
            keys.append(key)
    return keys


def categorize_appstream(raw_categories):
    """Return the list of our category keys matching AppStream/desktop categories."""
    raw = set(raw_categories or [])
    keys = [key for key, names in _APPSTREAM_RULES if raw & names]
    return keys or ["other"]


def categorize_section(section):
    """Return a one-element list of category keys for a Debian Section value."""
    section = (section or "").split("/")[-1].strip().lower()
    return [_SECTION_MAP.get(section, "other")]
