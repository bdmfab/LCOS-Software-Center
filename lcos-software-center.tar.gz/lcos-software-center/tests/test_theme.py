import json
import os
import sys
import tempfile
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from lcos_software_center import theme  # noqa: E402


class ThemeTests(unittest.TestCase):
    def test_hex_validation(self):
        for good in ("#000000", "#AbCdEf"):
            self.assertTrue(theme.valid_hex(good))
        for bad in ("000000", "#fff", "#gggggg", "red", "url(x)", "#ffffff;}", None, 5):
            self.assertFalse(theme.valid_hex(bad))

    def test_readable_text_picks_contrasting_color(self):
        self.assertEqual(theme.readable_text("#ffffff"), "#000000")
        self.assertEqual(theme.readable_text("#101010"), "#ffffff")
        self.assertEqual(theme.readable_text("#2b5797"), "#ffffff")
        self.assertEqual(theme.readable_text("#ffeb99"), "#000000")

    def test_css_only_for_customised_regions_and_auto_text(self):
        css = theme.build_css({"header": {"bg": "#2b5797", "fg": None}})
        self.assertIn("headerbar.lcos-header", css)
        self.assertIn("#2b5797", css)
        self.assertIn("color: #ffffff", css)
        self.assertNotIn("lcos-sidebar", css)
        self.assertNotIn("lcos-main", css)
        self.assertEqual(theme.build_css({}), "")

    def test_explicit_text_color_and_selection_preserved(self):
        css = theme.build_css({"sidebar": {"bg": "#202020", "fg": "#ff8800"},
                               "main": {"bg": "#fafafa", "fg": None}})
        self.assertIn("#ff8800", css)
        self.assertIn("row:selected", css)
        self.assertIn("treeview.view:selected", css)

    def test_untrusted_values_never_reach_css(self):
        css = theme.build_css({"header": {"bg": "red; } * { display: none", "fg": "#000000"},
                               "main": {"bg": "#ffffff", "fg": "url(http://x)"}})
        self.assertNotIn("display", css)
        self.assertNotIn("url", css)
        self.assertIn("lcos-main", css)           # the valid region still applies, bad fg becomes auto

    def test_save_load_round_trip_and_corrupt_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "sub", "theme.json")
            data = {"header": {"bg": "#AABBCC", "fg": None}, "main": {"bg": "#ffffff", "fg": "#000000"}}
            theme.save(data, path)
            self.assertEqual(theme.load(path)["header"], {"bg": "#aabbcc", "fg": None})
            self.assertEqual(os.listdir(os.path.dirname(path)), ["theme.json"])
            with open(path, "w") as fh:
                fh.write("{not json")
            self.assertEqual(theme.load(path), {})
            with open(path, "w") as fh:
                json.dump(["wrong", "type"], fh)
            self.assertEqual(theme.load(path), {})
            self.assertEqual(theme.load(os.path.join(tmp, "missing.json")), {})

    def test_config_path_honours_xdg(self):
        old = os.environ.get("XDG_CONFIG_HOME")
        os.environ["XDG_CONFIG_HOME"] = "/x/cfg"
        try:
            self.assertEqual(theme.config_path(), "/x/cfg/lcos-software-center/theme.json")
        finally:
            if old is None:
                del os.environ["XDG_CONFIG_HOME"]
            else:
                os.environ["XDG_CONFIG_HOME"] = old


if __name__ == "__main__":
    unittest.main()
