import gzip
import os
import sys
import tempfile
import textwrap
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from lcos_software_center import appstream, localmeta  # noqa: E402
from lcos_software_center.apt_backend import AptBackend  # noqa: E402
from lcos_software_center.categories import categorize_debtags  # noqa: E402

GEANY_DESKTOP = textwrap.dedent("""\
    [Desktop Entry]
    Type=Application
    Name=Geany
    Name[de]=Geany Editor
    GenericName=Integrated Development Environment
    Comment=A fast and lightweight IDE
    Icon=geany
    Categories=GTK;Development;IDE;
    Exec=geany %F

    [Desktop Action NewWindow]
    Name=New Window
    Exec=geany -i
""")

GEANY_METAINFO = textwrap.dedent("""\
    <?xml version="1.0" encoding="UTF-8"?>
    <component type="desktop-application">
      <id>org.geany.Geany</id>
      <name>Geany</name>
      <summary>Metainfo summary</summary>
      <description><p>Geany is a small and fast IDE.</p></description>
      <url type="homepage">https://www.geany.org</url>
    </component>
""")


class FakeRoot:
    """Builds a throwaway filesystem root with dpkg file lists and launchers."""

    def __init__(self, testcase):
        tmp = tempfile.TemporaryDirectory()
        testcase.addCleanup(tmp.cleanup)
        self.root = tmp.name

    def write(self, path, text):
        full = os.path.join(self.root, path.lstrip("/"))
        os.makedirs(os.path.dirname(full), exist_ok=True)
        with open(full, "w", encoding="utf-8") as fh:
            fh.write(text)

    def package(self, name, files):
        self.write("/var/lib/dpkg/info/%s.list" % name, "/usr\n/usr/bin\n" + "\n".join(files) + "\n")


class LocalMetaTests(unittest.TestCase):
    def setUp(self):
        self.fake = FakeRoot(self)
        self.fake.package("geany", ["/usr/bin/geany", "/usr/share/applications/geany.desktop",
                                     "/usr/share/metainfo/org.geany.Geany.metainfo.xml"])
        self.fake.write("/usr/share/applications/geany.desktop", GEANY_DESKTOP)
        self.fake.write("/usr/share/metainfo/org.geany.Geany.metainfo.xml", GEANY_METAINFO)
        # multiarch-style list name, hidden launcher, and a non-launcher package
        self.fake.package("libfoo1:amd64", ["/usr/lib/libfoo.so.1"])
        self.fake.package("hidden-thing", ["/usr/share/applications/hidden.desktop"])
        self.fake.write("/usr/share/applications/hidden.desktop",
                        "[Desktop Entry]\nType=Application\nName=Hidden\nNoDisplay=true\n")
        self.fake.package("some-link", ["/usr/share/applications/link.desktop"])
        self.fake.write("/usr/share/applications/link.desktop",
                        "[Desktop Entry]\nType=Link\nName=A link\nURL=http://example.org\n")

    def test_file_owners_strips_arch_and_filters_paths(self):
        owners = localmeta.file_owners(self.fake.root)
        self.assertEqual(owners["/usr/share/applications/geany.desktop"], "geany")
        self.assertNotIn("/usr/lib/libfoo.so.1", owners)

    def test_load_local_merges_desktop_and_metainfo(self):
        comps = {c.pkgname: c for c in localmeta.load_local(self.fake.root, langs=[])}
        self.assertEqual(set(comps), {"geany"})            # hidden + non-Application are skipped
        geany = comps["geany"]
        self.assertEqual(geany.name, "Geany")
        self.assertEqual(geany.summary, "A fast and lightweight IDE")   # desktop file wins
        self.assertEqual(geany.categories, ["GTK", "Development", "IDE"])
        self.assertEqual(geany.description, "Geany is a small and fast IDE.")
        self.assertEqual(geany.homepage, "https://www.geany.org")
        self.assertEqual(geany.stock_icon, "geany")
        self.assertIn("/usr/share/pixmaps/geany.png", geany.extra_icons)

    def test_localized_name_and_action_groups_ignored(self):
        comp = localmeta.parse_desktop(os.path.join(self.fake.root, "usr/share/applications/geany.desktop"),
                                       ["de_DE", "de"])
        self.assertEqual(comp.name, "Geany Editor")
        self.assertEqual(comp.id, "geany")

    def test_icon_variants(self):
        self.assertEqual(localmeta._icon_fields("/opt/app/icon.png"), ("", ["/opt/app/icon.png"]))
        self.assertEqual(localmeta._icon_fields("old.xpm"), ("", ["/usr/share/pixmaps/old.xpm"]))
        self.assertEqual(localmeta._icon_fields(""), ("", []))

    def test_catalog_integration_and_distro_count(self):
        catalog = appstream.load_catalog(files=[], langs=[], local_root=self.fake.root)
        self.assertEqual(catalog.count, 1)
        self.assertEqual(catalog.distro_count, 0)           # local data must not disable the fallback
        self.assertIn("geany", catalog.by_pkg)
        self.assertEqual(appstream.icon_candidates(catalog.by_pkg["geany"])[0], "geany")

    def test_explicit_files_skip_local_scan(self):
        catalog = appstream.load_catalog(files=[], langs=[])
        self.assertEqual(catalog.count, 0)

    def test_flatpak_components_are_not_distro(self):
        tmp = tempfile.mkdtemp()
        active = os.path.join(tmp, "flatpak", "appstream", "flathub", "x86_64", "active")
        os.makedirs(active)
        path = os.path.join(active, "appstream.xml.gz")
        with gzip.open(path, "wt", encoding="utf-8") as fh:
            fh.write('<components origin="flathub"><component type="desktop-application">'
                     "<id>org.example.App</id><name>App</name></component></components>")
        catalog = appstream.load_catalog(files=[path], langs=[])
        self.assertEqual((catalog.count, catalog.distro_count), (1, 0))


class DebtagTests(unittest.TestCase):
    def test_categories_from_tags(self):
        self.assertEqual(categorize_debtags("role::program, game::puzzle, uitoolkit::gtk"), ["games"])
        self.assertEqual(categorize_debtags("devel::editor, role::program"), ["development"])
        self.assertEqual(categorize_debtags("web::browser,use::browsing"), ["internet"])
        self.assertEqual(categorize_debtags("works-with::image use::editing"), ["graphics"])
        self.assertEqual(categorize_debtags("role::program, uitoolkit::gtk"), [])
        self.assertEqual(categorize_debtags(""), [])
        self.assertEqual(categorize_debtags(None), [])


class FakeBase:
    def __init__(self, name):
        self.name = name


class FakeCand:
    def __init__(self, tag=None, depends=()):
        self.record = {"Tag": tag} if tag is not None else {}
        self.dependencies = [[FakeBase(n)] for n in depends]


class ClassifyTests(unittest.TestCase):
    def test_tags_decide_when_present(self):
        self.assertEqual(AptBackend._classify(FakeCand("role::program, uitoolkit::gtk, game::puzzle")),
                         (True, "role::program, uitoolkit::gtk, game::puzzle"))
        self.assertEqual(AptBackend._classify(FakeCand("role::program, interface::commandline"))[0], False)
        self.assertEqual(AptBackend._classify(FakeCand("role::shared-lib"))[0], False)

    def test_multiline_tags_are_normalised(self):
        is_app, tags = AptBackend._classify(FakeCand("role::program,\n uitoolkit::qt,\n use::browsing"))
        self.assertTrue(is_app)
        self.assertEqual(tags, "role::program, uitoolkit::qt, use::browsing")

    def test_toolkit_dependency_fallback_without_tags(self):
        self.assertEqual(AptBackend._classify(FakeCand(None, ["libc6", "libgtk-3-0"])), (True, ""))
        self.assertEqual(AptBackend._classify(FakeCand(None, ["libc6", "libqt5widgets5"])), (True, ""))
        self.assertEqual(AptBackend._classify(FakeCand(None, ["libc6", "libssl3"])), (False, ""))

    def test_broken_record_does_not_raise(self):
        class Broken:
            @property
            def record(self):
                raise RuntimeError("bad record")
            dependencies = []
        self.assertEqual(AptBackend._classify(Broken()), (False, ""))


if __name__ == "__main__":
    unittest.main()
