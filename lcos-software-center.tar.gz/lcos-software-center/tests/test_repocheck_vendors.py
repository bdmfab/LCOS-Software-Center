import os
import sys
import tempfile
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from lcos_software_center import repocheck  # noqa: E402

USER_SOURCES = """\
deb http://ftp.fau.de/devuan/merged excalibur main contrib non-free-firmware
#deb-src http://ftp.fau.de/devuan/merged excalibur main contrib non-free-firmware
deb http://ftp.fau.de/devuan/merged excalibur-security main contrib non-free-firmware
#deb-src http://ftp.fau.de/devuan/merged excalibur-security main contrib non-free-firmware
deb http://ftp.fau.de/devuan/merged excalibur-updates main contrib non-free-firmware
#deb-src http://ftp.fau.de/devuan/merged excalibur-updates main contrib non-free-firmware
deb http://ftp.fau.de/devuan/merged excalibur-backports main contrib non-free-firmware
#deb-src http://ftp.fau.de/devuan/merged excalibur-backports main contrib non-free-firmware
"""


class VendorRepoTests(unittest.TestCase):
    def make_root(self, sources, extra=None):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        apt = os.path.join(tmp.name, "etc", "apt")
        os.makedirs(os.path.join(apt, "sources.list.d"))
        with open(os.path.join(apt, "sources.list"), "w") as fh:
            fh.write(sources)
        for name, text in (extra or {}).items():
            with open(os.path.join(apt, "sources.list.d", name), "w") as fh:
                fh.write(text)
        return tmp.name

    def test_users_real_sources_list_is_clean(self):
        self.assertEqual(repocheck.check(self.make_root(USER_SOURCES)), [])

    def test_vendor_repos_using_stable_are_not_reported(self):
        vendors = {
            "chrome.list": "deb [arch=amd64] https://dl.google.com/linux/chrome/deb/ stable main\n",
            "brave.list": "deb https://brave-browser-apt-release.s3.brave.com/ stable main\n",
            "spaces.list": "deb [arch=amd64 signed-by=/usr/share/keyrings/v.gpg] https://example.org/apt stable main\n",
            "vendor.sources": "Types: deb\nURIs: https://example.org/apt\nSuites: stable\nComponents: main\n",
        }
        self.assertEqual(repocheck.check(self.make_root(USER_SOURCES, vendors)), [])

    def test_devuan_mirror_on_other_host_with_suite_name_is_reported_with_file(self):
        root = self.make_root("deb http://ftp.fau.de/devuan/merged stable main\n")
        issues = repocheck.check(root)
        self.assertEqual([i.level for i in issues], ["info"])
        self.assertIn("stable in /etc/apt/sources.list", issues[0].text)

    def test_suite_name_in_devuan_file_under_sources_list_d_names_that_file(self):
        root = self.make_root(USER_SOURCES, {"devuan.list": "deb [arch=amd64] http://deb.devuan.org/merged testing main\n"})
        issues = repocheck.check(root)
        self.assertEqual(len(issues), 1)
        self.assertIn("testing in /etc/apt/sources.list.d/devuan.list", issues[0].text)

    def test_deb822_stanzas_are_judged_per_stanza(self):
        text = ("Types: deb\nURIs: https://example.org/apt\nSuites: stable\n\n"
                "Types: deb\nURIs: http://deb.devuan.org/merged\nSuites: unstable\n")
        issues = repocheck.check(self.make_root(USER_SOURCES, {"mixed.sources": text}))
        self.assertEqual(len(issues), 1)
        self.assertIn("unstable in /etc/apt/sources.list.d/mixed.sources", issues[0].text)
        self.assertNotIn("stable in /etc/apt/sources.list.d/mixed.sources, ", issues[0].text)

    def test_deb822_continuation_lines_and_disabled_stanzas(self):
        multi = "Types: deb\nURIs: http://deb.devuan.org/merged\nSuites: excalibur\n excalibur-updates\n"
        self.assertEqual(repocheck.check(self.make_root(USER_SOURCES, {"ok.sources": multi})), [])
        disabled = "Types: deb\nURIs: http://deb.devuan.org/merged\nSuites: stable\nEnabled: no\n"
        self.assertEqual(repocheck.check(self.make_root(USER_SOURCES, {"off.sources": disabled})), [])

    def test_foreign_repo_warning_still_works_next_to_vendor_repos(self):
        extra = {"mint.list": "deb http://packages.linuxmint.com wilma main\n",
                 "chrome.list": "deb [arch=amd64] https://dl.google.com/linux/chrome/deb/ stable main\n"}
        issues = repocheck.check(self.make_root(USER_SOURCES, extra))
        self.assertEqual([i.level for i in issues], ["warning"])

    def test_oneline_parser_handles_options(self):
        entry = repocheck._parse_oneline("deb [arch=amd64 signed-by=/k.gpg] http://x.org/devuan stable main", "p")
        self.assertEqual((entry.uris, entry.suites), (["http://x.org/devuan"], ["stable"]))
        self.assertIsNone(repocheck._parse_oneline("deb http://x.org", "p"))
        self.assertIsNone(repocheck._parse_oneline("# deb http://x.org stable main", "p"))


if __name__ == "__main__":
    unittest.main()
