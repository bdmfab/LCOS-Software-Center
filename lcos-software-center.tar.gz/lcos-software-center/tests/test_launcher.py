import os
import sys
import tempfile
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from lcos_software_center import launcher  # noqa: E402
from lcos_software_center.models import Item  # noqa: E402


class LauncherTests(unittest.TestCase):
    def setUp(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        self.app_dir = os.path.join(tmp.name, "applications") + "/"
        os.makedirs(self.app_dir)

    def desktop(self, name, body):
        path = self.app_dir + name
        with open(path, "w", encoding="utf-8") as fh:
            fh.write("[Desktop Entry]\n" + body)
        return path

    def test_picks_first_visible_launcher(self):
        hidden = self.desktop("a-hidden.desktop", "Type=Application\nName=Hidden\nNoDisplay=true\n")
        shown = self.desktop("b-shown.desktop", "Type=Application\nName=Shown\n")
        files = ["/usr/bin/tool", hidden, shown, self.app_dir + "readme.txt"]
        self.assertEqual(launcher.apt_launcher("pkg", lister=lambda p: files, app_dir=self.app_dir), shown)

    def test_none_when_package_has_no_launcher(self):
        self.assertIsNone(launcher.apt_launcher("pkg", lister=lambda p: ["/usr/bin/tool", "/usr/lib/x.so"],
                                                app_dir=self.app_dir))
        self.assertIsNone(launcher.apt_launcher("pkg", lister=lambda p: [], app_dir=self.app_dir))

    def test_ignores_desktop_files_outside_the_applications_dir(self):
        other = self.desktop("c.desktop", "Type=Application\nName=C\n")
        self.assertIsNone(launcher.apt_launcher("pkg", lister=lambda p: [other], app_dir="/usr/share/applications/"))

    def test_only_the_requested_package_is_queried(self):
        asked = []
        launcher.apt_launcher("geany", lister=lambda p: asked.append(p) or [], app_dir=self.app_dir)
        self.assertEqual(asked, ["geany"])

    def test_flatpak_argv(self):
        item = Item(source="flatpak", ident="com.example.Agenda", name="Agenda")
        self.assertEqual(launcher.flatpak_run_argv(item), ["flatpak", "run", "com.example.Agenda"])

    def test_launch_flatpak_reports_missing_binary(self):
        item = Item(source="flatpak", ident="com.example.Agenda", name="Agenda")
        old_path = os.environ.get("PATH", "")
        os.environ["PATH"] = "/nonexistent"
        try:
            self.assertIn("Could not start Agenda", launcher.launch_flatpak(item))
        finally:
            os.environ["PATH"] = old_path


if __name__ == "__main__":
    unittest.main()
