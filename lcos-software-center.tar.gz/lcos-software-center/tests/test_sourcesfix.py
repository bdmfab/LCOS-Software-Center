import datetime
import importlib.machinery
import importlib.util
import os
import sys
import tempfile
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from lcos_software_center import sourcesfix  # noqa: E402

HELPER = os.path.join(ROOT, "helper", "lcos-sc-helper")
_loader = importlib.machinery.SourceFileLoader("lcos_helper", HELPER)
_spec = importlib.util.spec_from_loader("lcos_helper", _loader)
helper = importlib.util.module_from_spec(_spec)
_loader.exec_module(helper)

LIST = """\
# main mirror
deb http://deb.devuan.org/merged stable main contrib
#deb-src http://deb.devuan.org/merged stable main contrib
deb http://deb.devuan.org/merged stable-security main
deb [arch=amd64 signed-by=/k.gpg] https://dl.google.com/linux/chrome/deb/ stable main
"""
SOURCES = """\
Types: deb
URIs: http://deb.devuan.org/merged
Suites: stable
 stable-updates
Components: main

Types: deb
URIs: https://example.org/apt
Suites: stable
Components: main
"""


def release(codename):
    return "Origin: Devuan\nSuite: stable\nCodename: %s\nDate: x\n" % codename


class Base(unittest.TestCase):
    def make_root(self, files, os_codename="excalibur", releases=None):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        r = tmp.name
        os.makedirs(os.path.join(r, "etc/apt/sources.list.d"))
        os.makedirs(os.path.join(r, "var/lib/apt/lists"))
        for rel, text in files.items():
            with open(os.path.join(r, "etc/apt", rel), "w") as fh:
                fh.write(text)
        if os_codename is not None:
            with open(os.path.join(r, "etc/os-release"), "w") as fh:
                fh.write('NAME="Devuan"\nVERSION_CODENAME=%s\n' % os_codename)
        for suite, name in (releases if releases is not None else
                            {"stable": "excalibur", "stable-security": "excalibur-security",
                             "stable-updates": "excalibur-updates"}).items():
            path = os.path.join(r, "var/lib/apt/lists/deb.devuan.org_merged_dists_%s_InRelease" % suite)
            with open(path, "w") as fh:
                fh.write("-----BEGIN PGP SIGNED MESSAGE-----\nHash: SHA512\n\n" + release(name)
                         + "-----BEGIN PGP SIGNATURE-----\nCodename: evil\n")
        return r


class PlanTests(Base):
    def test_codename_comes_from_release_file_and_vendor_repo_ignored(self):
        r = self.make_root({"sources.list": LIST})
        fix = sourcesfix.plan(r)
        self.assertTrue(fix.can_apply())
        self.assertEqual([(c.old, c.new) for c in fix.changes],
                         [("stable", "excalibur"), ("stable-security", "excalibur-security")])
        self.assertEqual(fix.installed_codename, "excalibur")
        self.assertIn("`excalibur`", sourcesfix.advice(fix, r))
        self.assertIn("/etc/apt/sources.list", sourcesfix.advice(fix, r))

    def test_refuses_when_system_older_than_suite(self):
        r = self.make_root({"sources.list": LIST}, os_codename="daedalus")
        fix = sourcesfix.plan(r)
        self.assertFalse(fix.can_apply())
        self.assertTrue(any("release upgrade" in p for p in fix.problems))
        self.assertIn("No automatic fix", sourcesfix.advice(fix, r))

    def test_refuses_without_release_info(self):
        r = self.make_root({"sources.list": LIST}, releases={})
        fix = sourcesfix.plan(r)
        self.assertFalse(fix.can_apply())
        self.assertTrue(any("apt update" in p for p in fix.problems))

    def test_refuses_when_suite_name_is_returned_as_codename(self):
        r = self.make_root({"sources.list": LIST}, releases={"stable": "stable", "stable-security": "x"})
        self.assertFalse(sourcesfix.plan(r).can_apply())

    def test_unknown_os_codename_does_not_block(self):
        r = self.make_root({"sources.list": LIST}, os_codename="lcosrolling")
        self.assertTrue(sourcesfix.plan(r).can_apply())

    def test_clean_sources_have_nothing_to_do(self):
        r = self.make_root({"sources.list": "deb http://deb.devuan.org/merged excalibur main\n"})
        fix = sourcesfix.plan(r)
        self.assertEqual(fix.changes, [])
        self.assertFalse(fix.can_apply())

    def test_signature_block_is_ignored(self):
        r = self.make_root({"sources.list": LIST})
        self.assertEqual(sourcesfix.release_codename(r, "http://deb.devuan.org/merged", "stable"), "excalibur")


class RewriteTests(Base):
    def test_oneline_changes_only_devuan_suite_token(self):
        new, n = sourcesfix.rewrite_oneline(LIST, {"stable": "excalibur", "stable-security": "excalibur-security"})
        self.assertEqual(n, 2)
        self.assertIn("deb http://deb.devuan.org/merged excalibur main contrib\n", new)
        self.assertIn("#deb-src http://deb.devuan.org/merged stable main contrib\n", new)   # comment kept
        self.assertIn("# main mirror\n", new)
        self.assertIn("chrome/deb/ stable main\n", new)                                     # vendor kept
        self.assertEqual(new.count("\n"), LIST.count("\n"))

    def test_deb822_changes_continuation_lines_and_leaves_vendor(self):
        new, n = sourcesfix.rewrite_deb822(SOURCES, {"stable": "excalibur", "stable-updates": "excalibur-updates"})
        self.assertEqual(n, 2)
        self.assertIn("Suites: excalibur\n excalibur-updates\n", new)
        self.assertIn("URIs: https://example.org/apt\nSuites: stable\n", new)

    def test_crlf_and_missing_final_newline_preserved(self):
        text = "deb http://deb.devuan.org/merged stable main\r\ndeb http://deb.devuan.org/merged stable main"
        new, n = sourcesfix.rewrite_oneline(text, {"stable": "excalibur"})
        self.assertEqual(new, text.replace("stable", "excalibur"))
        self.assertEqual(n, 2)


class ApplyTests(Base):
    def test_apply_backs_up_and_rewrites_both_formats(self):
        r = self.make_root({"sources.list": LIST, "sources.list.d/devuan.sources": SOURCES})
        fix = sourcesfix.plan(r)
        self.assertTrue(fix.can_apply(), fix.problems)
        diff = fix.line_diff(r)
        self.assertIn("- deb http://deb.devuan.org/merged stable main contrib", diff)
        self.assertIn("+ deb http://deb.devuan.org/merged excalibur main contrib", diff)
        os.chmod(os.path.join(r, "etc/apt/sources.list"), 0o640)
        when = datetime.datetime(2026, 1, 2, 3, 4, 5)
        backup, changed = sourcesfix.apply(fix, r, now=when)
        self.assertEqual(len(changed), 2)
        self.assertTrue(backup.endswith("20260102-030405"))
        with open(os.path.join(backup, "sources.list")) as fh:
            self.assertEqual(fh.read(), LIST)
        with open(os.path.join(r, "etc/apt/sources.list")) as fh:
            self.assertIn("excalibur main contrib", fh.read())
        self.assertEqual(os.stat(os.path.join(r, "etc/apt/sources.list")).st_mode & 0o777, 0o640)
        self.assertFalse([n for n in os.listdir(os.path.join(r, "etc/apt")) if n.startswith(".lcos-")])
        self.assertEqual(sourcesfix.plan(r).changes, [])          # idempotent: nothing left to do

    def test_symlinked_sources_file_keeps_symlink(self):
        r = self.make_root({"sources.list": ""})
        real = os.path.join(r, "real.list")
        with open(real, "w") as fh:
            fh.write(LIST)
        link = os.path.join(r, "etc/apt/sources.list")
        os.unlink(link)
        os.symlink(real, link)
        fix = sourcesfix.plan(r)
        sourcesfix.apply(fix, r)
        self.assertTrue(os.path.islink(link))
        with open(real) as fh:
            self.assertIn("excalibur main", fh.read())

    def test_digest_changes_with_plan(self):
        r = self.make_root({"sources.list": LIST})
        d1 = sourcesfix.plan(r).digest(r)
        r2 = self.make_root({"sources.list": LIST}, releases={"stable": "excalibur", "stable-security": "excalibur-x"})
        self.assertNotEqual(d1, sourcesfix.plan(r2).digest(r2))
        self.assertRegex(d1, r"^[0-9a-f]{64}$")


class HelperTests(unittest.TestCase):
    def test_command_is_fixed_and_digest_validated(self):
        good = "a" * 64
        self.assertEqual(helper.build_command(["fix-sources", good])[:2], [helper.APT_GET, "update"])
        for bad in ([], ["x"], ["A" * 64], ["a" * 63], ["a" * 64, "--extra"], ["../etc/passwd"]):
            with self.assertRaises(helper.UsageError):
                helper.build_command(["fix-sources"] + bad)

    def test_helper_refuses_user_owned_install(self):
        if os.geteuid() == 0:
            self.skipTest("running as root")
        with self.assertRaises(helper.RefusedError):
            helper.load_sourcesfix()


if __name__ == "__main__":
    unittest.main()
