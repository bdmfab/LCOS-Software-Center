import os
import subprocess
import sys
import tempfile
import unittest
from types import SimpleNamespace

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from lcos_software_center import sandbox_check  # noqa: E402


class SandboxCheckTests(unittest.TestCase):
    def setUp(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        self.proc = tmp.name
        self.calls = []

    def set(self, rel, value):
        path = os.path.join(self.proc, rel)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w") as fh:
            fh.write("%s\n" % value)

    def healthy(self):
        for name in sandbox_check.NS_LIMITS:
            self.set("sys/user/max_%s_namespaces" % name, 15000)

    def runner(self, returncode=0, stderr=""):
        def run(argv, **kwargs):
            self.calls.append(argv)
            return SimpleNamespace(returncode=returncode, stderr=stderr, stdout="")
        return run

    @staticmethod
    def which(*present):
        return lambda name: "/usr/bin/" + name if name in present else None

    def test_healthy_system_is_ok(self):
        self.healthy()
        status = sandbox_check.check(self.proc, self.runner(0), self.which("bwrap"))
        self.assertTrue(status.ok)
        self.assertEqual(status.explanation(), "")
        self.assertEqual(self.calls[0][0], "/usr/bin/bwrap")

    def test_zero_user_limit_is_reported_with_fix(self):
        self.healthy()
        self.set("sys/user/max_user_namespaces", 0)
        status = sandbox_check.check(self.proc, self.runner(0), self.which("bwrap"))
        self.assertFalse(status.ok)
        self.assertIn("user.max_user_namespaces is set to 0", status.problem)
        self.assertEqual(status.commands[0], "sudo sysctl -w user.max_user_namespaces=15000")
        self.assertIn("/etc/sysctl.d/99-userns.conf", status.commands[1])
        self.assertEqual(self.calls, [])                 # no need to probe when the cause is known
        self.assertIn("sudo sysctl -w", status.explanation())

    def test_several_zero_limits_are_all_listed(self):
        self.healthy()
        self.set("sys/user/max_user_namespaces", 0)
        self.set("sys/user/max_pid_namespaces", 0)
        status = sandbox_check.check(self.proc, self.runner(0), self.which("bwrap"))
        self.assertIn("user.max_user_namespaces, user.max_pid_namespaces are set to 0", status.problem)
        self.assertEqual(status.commands[0],
                         "sudo sysctl -w user.max_user_namespaces=15000 user.max_pid_namespaces=15000")

    def test_debian_clone_sysctl(self):
        self.healthy()
        self.set("sys/kernel/unprivileged_userns_clone", 0)
        status = sandbox_check.check(self.proc, self.runner(0), self.which("bwrap"))
        self.assertFalse(status.ok)
        self.assertIn("kernel.unprivileged_userns_clone=1", status.commands[0])

    def test_clone_sysctl_enabled_is_fine(self):
        self.healthy()
        self.set("sys/kernel/unprivileged_userns_clone", 1)
        self.assertTrue(sandbox_check.check(self.proc, self.runner(0), self.which("bwrap")).ok)

    def test_probe_failure_with_namespace_error_is_reported(self):
        self.healthy()
        err = "bwrap: Creating new namespace failed: nesting depth or /proc/sys/user/max_*_namespaces exceeded (ENOSPC)"
        status = sandbox_check.check(self.proc, self.runner(1, err), self.which("bwrap"))
        self.assertFalse(status.ok)
        self.assertIn("Creating new namespace failed", status.problem)
        self.assertEqual(status.commands, ["grep -H . /proc/sys/user/*"])

    def test_unrelated_probe_failure_is_not_blamed_on_namespaces(self):
        self.healthy()
        status = sandbox_check.check(self.proc, self.runner(1, "bwrap: execvp true: No such file"), self.which("bwrap"))
        self.assertTrue(status.ok)

    def test_falls_back_to_unshare_and_to_unknown(self):
        self.healthy()
        status = sandbox_check.check(self.proc, self.runner(1, "unshare: unshare failed: No space left on device"),
                                     self.which("unshare"))
        self.assertFalse(status.ok)
        self.assertEqual(self.calls[0][0], "/usr/bin/unshare")
        self.assertTrue(sandbox_check.check(self.proc, self.runner(1, "x"), self.which()).ok)   # nothing to probe with

    def test_probe_errors_do_not_raise(self):
        self.healthy()

        def boom(argv, **kwargs):
            raise subprocess.TimeoutExpired(argv, 15)
        self.assertTrue(sandbox_check.check(self.proc, boom, self.which("bwrap")).ok)

    def test_missing_proc_files_are_ok(self):
        self.assertTrue(sandbox_check.check(self.proc, self.runner(0), self.which("bwrap")).ok)

    def test_real_system_check_does_not_crash(self):
        status = sandbox_check.check()
        self.assertIsInstance(status.ok, bool)


if __name__ == "__main__":
    unittest.main()
