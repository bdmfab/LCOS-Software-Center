import gzip
import importlib.machinery
import importlib.util
import os
import sys
import tempfile
import textwrap
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from lcos_software_center import appstream, categories, flatpak_backend, repocheck, runner  # noqa: E402
from lcos_software_center.apt_backend import SimResult, init_warnings, parse_simulation  # noqa: E402
from lcos_software_center.models import Item, human_size  # noqa: E402


def load_helper():
    path = os.path.join(ROOT, "helper", "lcos-sc-helper")
    loader = importlib.machinery.SourceFileLoader("lcos_sc_helper", path)
    spec = importlib.util.spec_from_loader("lcos_sc_helper", loader)
    module = importlib.util.module_from_spec(spec)
    loader.exec_module(module)
    return module


APPSTREAM_XML = textwrap.dedent("""\
    <?xml version="1.0" encoding="UTF-8"?>
    <components version="0.14" origin="debian-trixie-main">
      <component type="desktop-application">
        <id>org.gimp.GIMP.desktop</id>
        <pkgname>gimp</pkgname>
        <name>GNU Image Manipulation Program</name>
        <name xml:lang="de">GIMP Bildbearbeitung</name>
        <summary>Create images and edit photographs</summary>
        <description>
          <p>GIMP is a raster editor.</p>
          <p xml:lang="de">GIMP ist ein Rasterbildeditor.</p>
          <ul><li>Layers</li><li>Filters</li></ul>
        </description>
        <categories><category>Graphics</category><category>2DGraphics</category></categories>
        <url type="homepage">https://www.gimp.org</url>
        <icon type="cached" width="64" height="64">gimp_gimp.png</icon>
        <icon type="stock">gimp</icon>
      </component>
      <component type="runtime">
        <id>org.example.Runtime</id>
        <name>Not an app</name>
      </component>
      <component type="console-application">
        <id>org.example.Cli</id>
        <name>Console app</name>
      </component>
    </components>
""")


class AppStreamTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.xml_dir = os.path.join(self.tmp.name, "swcatalog", "xml")
        os.makedirs(self.xml_dir)
        self.path = os.path.join(self.xml_dir, "debian-main.xml.gz")
        with gzip.open(self.path, "wt", encoding="utf-8") as fh:
            fh.write(APPSTREAM_XML)

    def test_parses_only_graphical_apps(self):
        comps = list(appstream.iter_components(self.path))
        self.assertEqual([c.id for c in comps], ["org.gimp.GIMP"])   # '.desktop' stripped
        gimp = comps[0]
        self.assertEqual(gimp.pkgname, "gimp")
        self.assertEqual(gimp.origin, "debian-trixie-main")
        self.assertEqual(gimp.name, "GNU Image Manipulation Program")
        self.assertEqual(gimp.homepage, "https://www.gimp.org")
        self.assertEqual(gimp.stock_icon, "gimp")
        self.assertIn("Layers", gimp.description)

    def test_localization(self):
        gimp = next(appstream.iter_components(self.path, ["de_DE", "de"]))
        self.assertEqual(gimp.name, "GIMP Bildbearbeitung")
        self.assertTrue(gimp.description.startswith("GIMP ist ein"))

    def test_catalog_indexes_and_icon_paths(self):
        catalog = appstream.load_catalog([self.path], langs=[])
        self.assertEqual(catalog.count, 1)
        comp = catalog.by_pkg["gimp"]
        self.assertIs(comp, catalog.by_id["org.gimp.GIMP"])
        cands = appstream.icon_candidates(comp)
        expected = os.path.join(self.tmp.name, "swcatalog", "icons", "debian-trixie-main", "64x64", "gimp_gimp.png")
        self.assertEqual(cands, [expected, "gimp"])

    def test_flatpak_icon_layout(self):
        comp = appstream.Component(id="x.y.Z", source_file="/v/flatpak/appstream/flathub/x86_64/active/appstream.xml.gz",
                                   cached_icons=[(128, "b.png"), (64, "a.png")], stock_icon="")
        self.assertEqual(appstream.icon_candidates(comp), [
            "/v/flatpak/appstream/flathub/x86_64/active/icons/64x64/a.png",
            "/v/flatpak/appstream/flathub/x86_64/active/icons/128x128/b.png",
        ])

    def test_broken_files_are_ignored(self):
        bad = os.path.join(self.tmp.name, "bad.xml.gz")
        with open(bad, "wb") as fh:
            fh.write(b"not gzip")
        self.assertEqual(list(appstream.iter_components(bad)), [])
        self.assertEqual(list(appstream.iter_components("/nonexistent.xml")), [])

    def test_current_langs(self):
        self.assertEqual(appstream.current_langs({"LANG": "de_DE.UTF-8"}), ["de_DE", "de"])
        self.assertEqual(appstream.current_langs({"LANG": "C.UTF-8"}), [])
        self.assertEqual(appstream.current_langs({}), [])


class CategoryTests(unittest.TestCase):
    def test_appstream_mapping(self):
        self.assertEqual(categories.categorize_appstream(["Network", "WebBrowser"]), ["internet"])
        self.assertEqual(categories.categorize_appstream(["AudioVideo", "Player"]), ["multimedia"])
        self.assertEqual(categories.categorize_appstream(["Graphics", "Utility"]), ["graphics", "accessories"])
        self.assertEqual(categories.categorize_appstream(["Weird"]), ["other"])
        self.assertEqual(categories.categorize_appstream([]), ["other"])

    def test_section_mapping(self):
        self.assertEqual(categories.categorize_section("games"), ["games"])
        self.assertEqual(categories.categorize_section("contrib/graphics"), ["graphics"])
        self.assertEqual(categories.categorize_section("nonsense"), ["other"])
        self.assertEqual(categories.categorize_section(None), ["other"])

    def test_every_mapped_key_is_a_real_category(self):
        keys = {k for k, _, _ in categories.CATEGORIES}
        self.assertTrue(set(categories._SECTION_MAP.values()) <= keys)
        self.assertTrue({k for k, _ in categories._APPSTREAM_RULES} <= keys)


class RepoCheckTests(unittest.TestCase):
    def make_root(self, sources, extra=None):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        apt = os.path.join(tmp.name, "etc", "apt")
        os.makedirs(os.path.join(apt, "sources.list.d"))
        with open(os.path.join(apt, "sources.list"), "w") as fh:
            fh.write(sources)
        for name, text in (extra or {}).items():
            with open(os.path.join(apt, "sources.list.d", name), "w") as fh:
                fh.write(text)
        return tmp.name

    def test_clean_devuan_config(self):
        root = self.make_root(
            "deb http://deb.devuan.org/merged excalibur main\n"
            "deb http://deb.devuan.org/merged excalibur-updates main\n"
            "deb http://deb.devuan.org/merged excalibur-security main\n")
        self.assertEqual(repocheck.check(root), [])

    def test_foreign_repo_warns(self):
        root = self.make_root("deb http://deb.devuan.org/merged excalibur main\n",
                              {"mint.list": "deb http://packages.linuxmint.com wilma main\n"})
        issues = repocheck.check(root)
        self.assertEqual([i.level for i in issues], ["warning"])
        self.assertIn("packages.linuxmint.com", issues[0].text)

    def test_debian_repo_warns(self):
        root = self.make_root("deb http://deb.debian.org/debian trixie main\n")
        self.assertEqual(repocheck.check(root)[0].level, "warning")

    def test_suite_names_and_https_are_info(self):
        root = self.make_root("deb https://deb.devuan.org/merged stable main\n")
        levels = [i.level for i in repocheck.check(root)]
        self.assertEqual(levels, ["info", "info"])

    def test_deb822_suites(self):
        root = self.make_root("", {"devuan.sources": "Types: deb\nURIs: http://deb.devuan.org/merged\nSuites: testing\n"})
        self.assertEqual([i.level for i in repocheck.check(root)], ["info"])

    def test_missing_files_are_fine(self):
        self.assertEqual(repocheck.check(tempfile.mkdtemp()), [])


class RunnerTests(unittest.TestCase):
    def test_apt_status_lines(self):
        frac, text = runner.parse_progress("pmstatus:gimp:42.5000:Unpacking gimp (2.10) ...")
        self.assertAlmostEqual(frac, 0.425)
        self.assertIn("Unpacking", text)
        frac, text = runner.parse_progress("dlstatus:1:10.0:Downloading")
        self.assertAlmostEqual(frac, 0.10)
        self.assertEqual(runner.parse_progress("pmstatus:x:abc:y"), None)

    def test_percent_lines(self):
        self.assertAlmostEqual(runner.parse_progress("Installing org.gimp.GIMP  45%")[0], 0.45)
        self.assertIsNone(runner.parse_progress("Reading package lists..."))
        self.assertIsNone(runner.parse_progress("Total 250% weird"))

    def test_run_streams_output_and_exit_code(self):
        lines, progress = [], []
        rc = runner.run([sys.executable, "-c",
                         "print('hello'); print('pmstatus:p:50.0:half'); import sys; sys.exit(3)"],
                        lines.append, lambda f, t: progress.append((f, t)))
        self.assertEqual(rc, 3)
        self.assertEqual(lines, ["hello"])           # status lines are not echoed to the log
        self.assertEqual(progress, [(0.5, "half")])

    def test_run_missing_binary(self):
        lines = []
        self.assertEqual(runner.run(["/no/such/binary"], lines.append, lambda f, t: None), 127)
        self.assertTrue(lines)

    def test_failure_messages(self):
        self.assertIn("cancelled", runner.describe_failure(["pkexec", "x"], 126))
        self.assertIn("exit code 100", runner.describe_failure(["flatpak"], 100))


class FlatpakTests(unittest.TestCase):
    def test_parse_size_variants(self):
        ps = flatpak_backend.parse_size
        self.assertEqual(ps("12.3 MB"), 12300000)
        self.assertEqual(ps("12.3\u00a0MB"), 12300000)
        self.assertEqual(ps("12.3\u202fMB"), 12300000)
        self.assertEqual(ps("36.3?MB"), 36300000)
        self.assertEqual(ps("1.0 GB"), 1000000000)
        self.assertEqual(ps("800 bytes"), 800)
        self.assertEqual(ps("1.5 GB"), 1500000000)
        self.assertEqual(ps("< 1 kB"), 1000)
        self.assertEqual(ps("2 MiB"), 2 * 1024 ** 2)
        for bad in ("", "n/a", "unknown", "12"):
            self.assertEqual(ps(bad), 0)

    def test_parse_size_table(self):
        table = flatpak_backend.parse_size_table("org.a.B\t5.2 MB\t20.0 MB\norg.c.D\t\t\nnoise\n")
        self.assertEqual(table, {"org.a.B": (5200000, 20000000), "org.c.D": (0, 0)})

    def test_parse_remote_ls(self):
        text = ("org.gimp.GIMP\tGIMP\tImage editor\t3.0.4\tflathub\n"
                "org.example.NoVersion\tNoVer\tSummary only\n"
                "garbage line\n"
                "\n")
        rows = flatpak_backend.parse_remote_ls(text)
        self.assertEqual([r["id"] for r in rows], ["org.gimp.GIMP", "org.example.NoVersion"])
        self.assertEqual(rows[0]["origin"], "flathub")
        self.assertEqual(rows[1]["version"], "")
        self.assertEqual(rows[1]["origin"], "flathub")      # default when column missing

    def test_argv_builders(self):
        item = Item(source="flatpak", ident="org.gimp.GIMP", name="GIMP", origin="flathub")
        os.environ.pop("LCOS_SC_FLATPAK_SCOPE", None)
        self.assertEqual(flatpak_backend.install_argv(item),
                         ["flatpak", "install", "--system", "-y", "--noninteractive", "flathub", "org.gimp.GIMP"])
        os.environ["LCOS_SC_FLATPAK_SCOPE"] = "user"
        try:
            self.assertIn("--user", flatpak_backend.remove_argv(item))
            self.assertEqual(flatpak_backend.update_argv()[-1], "--noninteractive")
        finally:
            del os.environ["LCOS_SC_FLATPAK_SCOPE"]


class AptSimulationTests(unittest.TestCase):
    OUTPUT = textwrap.dedent("""\
        NOTE: This is only a simulation!
        Inst libfoo1 (1.0 Devuan:6.0/stable [amd64])
        Inst gimp (2.10.36-3 Devuan:6.0/stable [amd64])
        Remv oldthing [1.2]
        Conf gimp (2.10.36-3 Devuan:6.0/stable [amd64])
    """)

    def test_parse(self):
        sim = parse_simulation(self.OUTPUT)
        self.assertEqual(sim.install, ["libfoo1", "gimp"])
        self.assertEqual(sim.remove, ["oldthing"])

    def test_init_guard(self):
        self.assertEqual(init_warnings(SimResult(install=["gimp"])), [])
        self.assertEqual(len(init_warnings(SimResult(install=["systemd-sysv"]))), 1)
        self.assertEqual(len(init_warnings(SimResult(remove=["sysvinit-core", "elogind"]))), 1)


class HelperTests(unittest.TestCase):
    def setUp(self):
        self.helper = load_helper()

    def test_valid_commands(self):
        cmd = self.helper.build_command(["install", "gimp", "libreoffice-writer", "g++:amd64"])
        self.assertEqual(cmd[:2], ["/usr/bin/apt-get", "install"])
        self.assertEqual(cmd[-3:], ["gimp", "libreoffice-writer", "g++:amd64"])
        self.assertIn("APT::Status-Fd=1", cmd)
        self.assertEqual(self.helper.build_command(["upgrade-all"])[:2], ["/usr/bin/apt-get", "upgrade"])
        self.assertEqual(self.helper.build_command(["update"])[:2], ["/usr/bin/apt-get", "update"])
        self.assertIn("--only-upgrade", self.helper.build_command(["upgrade", "gimp"]))

    def test_rejects_bad_input(self):
        bad = [
            [], ["frobnicate"], ["install"], ["install", "--reinstall"], ["install", "-o", "x=y"],
            ["install", "gimp;rm -rf /"], ["install", "GIMP"], ["install", "../etc/passwd"],
            ["remove", "$(id)"], ["update", "extra"], ["upgrade-all", "gimp"],
            ["install"] + ["pkg%d" % i for i in range(25)],
        ]
        for args in bad:
            with self.assertRaises(self.helper.UsageError, msg=str(args)):
                self.helper.build_command(args)

    def test_requires_root(self):
        if os.geteuid() != 0:
            self.assertEqual(self.helper.main(["x", "update"]), 1)


class MiscTests(unittest.TestCase):
    def test_human_size(self):
        self.assertEqual(human_size(0), "unknown")
        self.assertEqual(human_size(512), "512 B")
        self.assertEqual(human_size(1500000), "1.5 MB")

    def test_item_key(self):
        self.assertEqual(Item(source="apt", ident="gimp", name="GIMP").key, "apt:gimp")


if __name__ == "__main__":
    unittest.main()
